#!/bin/sh
#
# Author: Matthias Ihmig <m.ihmig@mytum.de>
# Last change: 6/25/2005
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU Library General Public License

set -e

[ -z "$MAKEROOTFS_CONFIG" ] && MAKEROOTFS_CONFIG=$PWD/makerootfs.conf
[ ! -e $MAKEROOTFS_CONFIG ] && echo "ERROR: Config file ($MAKEROOTFS_CONFIG) not found!" && exit
. $MAKEROOTFS_CONFIG

! which $TARGET_CC && echo "ERROR: Can't find $TARGET_CC in PATH!" && exit

FILE=glib-1.2.10.tar.gz
BASEURL=ftp://ftp.gtk.org/pub/gtk/v1.2/
SRCDIR=glib-1.2.10

echo === Building $FILE ===

cd $DOWNLOADS
[ ! -e "$FILE" ] && `$WGET $BASEURL$FILE`
cd $BUILDDIR
[ ! -e "$SRCDIR" ] && tar xvzf $DOWNLOADS/$FILE

cd $SRCDIR

[ ! -e $BUILDDIR/$SRCDIR/.patch_applied ] && cat $PATCHES/libglib_configure_1.2.10.patch | patch -N -p1
[ ! -e $BUILDDIR/$SRCDIR/.patch_applied ] && cat $PATCHES/libglib_gcc34-fix.patch | patch -N -p1
touch $BUILDDIR/$SRCDIR/.patch_applied

rm -rf config.cache

CC=$TARGET_CC CFLAGS="$TARGET_CFLAGS" ./configure --host=$CROSS_HOST \
	--prefix=$ROOTFS_STAGING/usr --enable-shared --disable-nls

make CC=$TARGET_CC
make prefix=$ROOTFS_STAGING/usr install

mv $ROOTFS_STAGING/usr/lib/glib/include/* $ROOTFS_STAGING/usr/include/glib-1.2
mv $ROOTFS_STAGING/usr/bin/glib-config $BUILDDIR/glib-config
rm -rf $ROOTFS_STAGING/usr/lib/glib


cd ..
