#!/bin/sh
#
# Author: Matthias Ihmig <m.ihmig@mytum.de>
# Last change: 6/25/2005
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU Library General Public License

set -e

[ -z "$MAKEROOTFS_CONFIG" ] && MAKEROOTFS_CONFIG=$PWD/makerootfs.conf
[ ! -e $MAKEROOTFS_CONFIG ] && echo "ERROR: Config file ($MAKEROOTFS_CONFIG) not found!" && exit
. $MAKEROOTFS_CONFIG

! which $TARGET_CC && echo "ERROR: Can't find $TARGET_CC in PATH!" && exit

FILE=gdb-6.3.tar.gz
BASEURL=http://ftp.gnu.org/gnu/gdb/
SRCDIR=gdb-6.3

echo === Building $FILE ===

cd $DOWNLOADS
[ ! -e "$FILE" ] && `$WGET $BASEURL$FILE`
cd $BUILDDIR
[ ! -e "$SRCDIR" ] && tar xvzf $DOWNLOADS/$FILE

# only install host debugger if it doesn't exist yet
if ! which $CROSS_HOST-gdb
then
	echo === Building $CROSS_HOST-gdb

	cd $BUILDDIR/$SRCDIR
	./configure --target=$CROSS_HOST --prefix=$BUILDDIR/$SRCDIR/usr --disable-nls
	make

	TMP1=`which $TARGET_CC`
	CROSS_PATH=`dirname $TMP1`
	install -m 0755 gdb/gdb $CROSS_PATH/$CROSS_HOST-gdb
	echo "=== gdb debugger installed into $CROSS_PATH/$CROSS_HOST-gdb"
else
	echo "!!! not building $CROSS_HOST-gdb as it already exists in PATH"
fi

echo === Building gdbserver
cd $BUILDDIR/$SRCDIR/gdb/gdbserver

CC=$TARGET_CC ./configure --host=$CROSS_HOST --disable-nls
make

mkdir -p $ROOTFS_STAGING/usr/bin
install -m 0755 gdbserver $ROOTFS_STAGING/usr/bin

cd ..
