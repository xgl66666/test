#!/bin/bash
#
# Author: Matthias Ihmig <m.ihmig@mytum.de>
# Last change: 6/25/2005
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU Library General Public License

set -e

[ -z "$MAKEROOTFS_CONFIG" ] && MAKEROOTFS_CONFIG=$PWD/makerootfs.conf
[ ! -e $MAKEROOTFS_CONFIG ] && echo "ERROR: Config file ($MAKEROOTFS_CONFIG) not found!" && exit
. $MAKEROOTFS_CONFIG

! which $TARGET_CC && echo "ERROR: Can't find $TARGET_CC in PATH!" && exit

FILE=ncurses-5.4.tar.gz
BASEURL=ftp://ftp.gnu.org/pub/gnu/ncurses/
SRCDIR=ncurses-5.4

# The following terminfos are kept and _not_ cleaned out
TERMS="/unknown$|/linux$|/linux-vt$|/vt100\+keypad$|/vt100\+pfkeys$|/vt100\+fnkeys$|/vt100|/vt220$|/vt52$|/vt102$|/ansi$|/screen$|/screen.xterm-xfree86$|/screen.xterm-r6$|/screen.linux$|/sun$|/xterm-bw$|/xterm-xfree86$|/xterm-16color$|/xterm-color$|/rxvt-basic$|/rxvt$|/rxvt-color$|/rxvt-16color$|/dumb$|/vt200$|/xterm$"

echo === Building $FILE ===

cd $DOWNLOADS
[ ! -e "$FILE" ] && `$WGET $BASEURL$FILE`
cd $BUILDDIR
[ ! -d $SRCDIR ] && tar xvzf $DOWNLOADS/$FILE

cd $SRCDIR
#use the local tic and not whatever the build system was going to find.
sed -i 's~\$$srcdir/shlib tic\$$suffix~/usr/bin/tic~' misc/run_tic.in

CC=$TARGET_CC HOSTCC=$HOSTCC CFLAGS=$CFLAGS CPPFLAGS="-I$ROOTFS_STAGING/usr/include" LDFLAGS="-L$ROOTFS_STAGING/usr/lib" \
	./configure --prefix=/usr --sysconfdir=/etc --datadir=/usr/share \
		--target=$CROSS_HOST --host=$CROSS_HOST \
		--build=i686-linux --with-shared --without-debug \
		--without-profile --disable-rpath --enable-echo \
		--enable-const --enable-termcap --enable-overwrite \
		--without-ada --without-progs --without-cxx \
		--without-cxx-binding --with-gpm --disable-nls \
		--with-terminfo-dirs=/usr/share/terminfo \
		--with-default-terminfo-dir=/usr/share/terminfo \
		BUILD_CC=gcc DESTDIR=$ROOTFS_STAGING

make prefix=$ROOTFS_STAGING ticdir=$ROOTFS_STAGING/usr/share/terminfo \
	HOSTCC=$HOSTCC CFLAGS=$CFLAGS DESTDIR=$ROOTFS_STAGING
make DESTDIR=$ROOTFS_STAGING install

mkdir -p $ROOTFS_STAGING/etc
rm $ROOTFS_STAGING/etc/terminfo && echo
ln -sf /usr/share/terminfo $ROOTFS_STAGING/etc/terminfo

echo "*** Cleaning out terminfo database... Don't mind errors."

cd $ROOTFS_STAGING/usr/share/terminfo
find -type f | grep -v -E "$TERMS" | xargs -n1 -t -r rm
find -type l | grep -v -E "$TERMS" | xargs -n1 -t -r rm
rmdir * > /dev/null && echo

cd ..
