#!/bin/sh
#
# Author: Matthias Ihmig <m.ihmig@mytum.de>
# Last change: 6/25/2005
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU Library General Public License

set -e

[ -z "$MAKEROOTFS_CONFIG" ] && MAKEROOTFS_CONFIG=$PWD/makerootfs.conf
[ ! -e $MAKEROOTFS_CONFIG ] && echo "ERROR: Config file ($MAKEROOTFS_CONFIG) not found!" && exit
. $MAKEROOTFS_CONFIG

! which $TARGET_CC && echo "ERROR: Can't find $TARGET_CC in PATH!" && exit

FILE=aumix-2.8.tar.bz2
BASEURL=http://www.jpj.net/~trevor/aumix/
SRCDIR=aumix-2.8

DSPINFO=dsp_info
DSPINFOURL=http://adlib.rsch.tuis.ac.jp/~akira/unix/ossprog/src/short/dsp_info.c

echo === Building $FILE ===

cd $DOWNLOADS
[ ! -e "$FILE" ] && `$WGET $BASEURL$FILE`
[ ! -e "$DSPINFO.c" ] && `$WGET $DSPINFOURL` && echo -n
[ ! -e "$DSPINFO.c" ] && `$WGET $BASEURLMIRROR$DSPINFO.c`

cd $BUILDDIR
[ ! -e "$SRCDIR" ] && tar xvjf $DOWNLOADS/$FILE && cp $DOWNLOADS/$DSPINFO.c $SRCDIR

cd $SRCDIR

$TARGET_CC $DSPINFO.c -o $DSPINFO

LD=$TARGET_LD CC=$TARGET_CC CFLAGS="$TARGET_CFLAGS -I$ROOTFS_STAGING/usr/include" LDFLAGS="-L$ROOTFS_STAGING/usr/lib" CPPFLAGS="-I$ROOTFS_STAGING/usr/include" ./configure --host=$CROSS_HOST --prefix=$ROOTFS_STAGING/usr --localstatedir=/var --without-gtk --without-gtk1 --disable-nls $CROSS_HOST

make
make install
mkdir -p $ROOTFS_STAGING/etc/init.d/run
install -m 0644 $PATCHES/aumix-aumixrc $ROOTFS_STAGING/etc/aumixrc
install -m 0755 $PATCHES/aumix-oss-initd $ROOTFS_STAGING/etc/init.d/oss
ln -sf ../oss $ROOTFS_STAGING/etc/init.d/run/S80sound
install -m 0755 $DSPINFO $ROOTFS_STAGING/usr/bin

cd ..

