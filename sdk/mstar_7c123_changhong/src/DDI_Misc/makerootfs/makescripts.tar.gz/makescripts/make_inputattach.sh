#!/bin/sh
#
# Author: Matthias Ihmig <m.ihmig@mytum.de>
# Last change: 6/25/2005
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU Library General Public License

set -e

[ -z "$MAKEROOTFS_CONFIG" ] && MAKEROOTFS_CONFIG=$PWD/makerootfs.conf
[ ! -e $MAKEROOTFS_CONFIG ] && echo "ERROR: Config file ($MAKEROOTFS_CONFIG) not found!" && exit
. $MAKEROOTFS_CONFIG

! which $TARGET_CC && echo "ERROR: Can't find $TARGET_CC in PATH!" && exit

FILE=inputattach.c
FILEURL=http://cvs.sourceforge.net/viewcvs.py/*checkout*/linuxconsole/ruby/utils/$FILE?rev=1.22
SRCDIR=inputattach
FILEBIN=inputattach
FILEBINURL=http://makerootfs.sourceforge.net/

echo === Building $FILE ===

cd $DOWNLOADS
[ ! -e "$FILE" ] && `$WGET $FILEURL` && mv $FILE\?rev\=1.22 $FILE
[ ! -e "$FILEBIN" ] && `$WGET $FILEBINURL$FILEBIN`

cd $BUILDDIR
[ ! -e "$SRCDIR" ] && mkdir -p $SRCDIR/linux && cp $DOWNLOADS/$FILE $SRCDIR && cp $DOWNLOADS/$FILEBIN $SRCDIR

cd $SRCDIR

[ ! -e $BUILDDIR/$SRCDIR/.patch_applied ] && patch -N -p0 < $PATCHES/inputattach-serialfastap.patch
touch $BUILDDIR/$SRCDIR/.patch_applied

mkdir -p $ROOTFS_STAGING/etc/conf.d/
mkdir -p $ROOTFS_STAGING/etc/init.d/run
mkdir -p $ROOTFS_STAGING/sbin/

# comment the following line to use precompiled binary, because sources only compile with gcc 3.3
# $TARGET_CC $FILE -o $FILEBIN

install -m 0755 $FILEBIN $ROOTFS_STAGING/sbin/

install -m 0644 $PATCHES/inputattach-confd-input $ROOTFS_STAGING/etc/conf.d/input
install -m 0755 $PATCHES/inputattach-initd $ROOTFS_STAGING/etc/init.d/inputattach
ln -sf ../inputattach $ROOTFS_STAGING/etc/init.d/run/S30inputattach

if [ -d $ROOTFS_STAGING/etc/apm/scripts.d ]
then
	cd $ROOTFS_STAGING/etc/apm
	install -m 0755 $PATCHES/inputattach-apm scripts.d/inputattach
	ln -sf ../scripts.d/inputattach resume.d/40inputattach && echo -n
	ln -sf ../scripts.d/inputattach suspend.d/40inputattach && echo -n
fi

cd ..
