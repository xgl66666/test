#!/bin/sh
#
# Author: Matthias Ihmig <m.ihmig@mytum.de>
# Last change: 6/25/2005
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU Library General Public License

set -e

[ -z "$MAKEROOTFS_CONFIG" ] && MAKEROOTFS_CONFIG=$PWD/makerootfs.conf
[ ! -e $MAKEROOTFS_CONFIG ] && echo "ERROR: Config file ($MAKEROOTFS_CONFIG) not found!" && exit
. $MAKEROOTFS_CONFIG

! which $TARGET_CC && echo "ERROR: Can't find $TARGET_CC in PATH!" && exit

FILE=libpcap-0.8.3.tar.gz
BASEURL=http://www.tcpdump.org/release/
SRCDIR=libpcap-0.8.3

echo === Building $FILE ===

cd $DOWNLOADS
[ ! -e "$FILE" ] && `$WGET $BASEURL$FILE`
cd $BUILDDIR
[ ! -e "$SRCDIR" ] && tar xvzf $DOWNLOADS/$FILE

cd $SRCDIR

[ ! -e $BUILDDIR/$SRCDIR/.patch_applied ] && patch -N -p1 < $PATCHES/libpcap-crosscompile.patch
touch $BUILDDIR/$SRCDIR/.patch_applied

CFLAGS="$TARGET_CFLAGS" LDFLAGS="-L$ROOTFS_STAGING/usr/lib" CPPFLAGS="-I$ROOTFS_STAGING/usr/include" ./configure --prefix=$ROOTFS_STAGING/usr --host=$CROSS_HOST --with-pcap=linux --with-linux-vers=2.6.9

make
make install
cd ..
