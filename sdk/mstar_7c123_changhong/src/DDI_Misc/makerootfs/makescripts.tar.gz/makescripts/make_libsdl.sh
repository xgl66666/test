#!/bin/bash
#
# Author: Matthias Ihmig <m.ihmig@mytum.de>
# Last change: 6/25/2005
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU Library General Public License

set -e

[ -z "$MAKEROOTFS_CONFIG" ] && MAKEROOTFS_CONFIG=$PWD/makerootfs.conf
[ ! -e $MAKEROOTFS_CONFIG ] && echo "ERROR: Config file ($MAKEROOTFS_CONFIG) not found!" && exit
. $MAKEROOTFS_CONFIG

! which $TARGET_CC && echo "ERROR: Can't find $TARGET_CC in PATH!" && exit

FILE=SDL-1.2.8.tar.gz
BASEURL=http://www.libsdl.org/release/
SRCDIR=SDL-1.2.8

echo === Building $FILE ===

cd $DOWNLOADS
[ ! -e "$FILE" ] && $WGET $BASEURL$FILE
cd $BUILDDIR
[ ! -e "$SRCDIR" ] && tar xvzf $DOWNLOADS/$FILE

cd $SRCDIR

./configure --enable-release --target=$CROSS_HOST --host=$CROSS_HOST --prefix=/usr \
	--disable-joystick --disable-cdrom --disable-esd --disable-alsa --disable-arts \
	--disable-mintaudio --disable-nasm \
	--disable-video-x11 --disable-video-x11-vm --disable-dga --disable-x11-dgamouse \
	--disable-video-x11-xv --disable-video-x11-xinerama --disable-video-x11-xme \
	--disable-video-dga --disable-video-photon --disable-video-ps2gs \
	--disable-video-xbios --disable-video-gem --disable-atari-ldg \
	--enable-qtopia --disable-video-opengl --disable-osmesa-shared --disable-directx \
	--without-x
	# --with-alsa-prefix=$ROOTFS_STAGING/usr/lib --with-alsa-inc-prefix=$ROOTFS_STAGING/usr/include \
	# --x-includes=/usr/local/arm/2.95.3/arm-linux/usr/X11R6/include \
	# --x-libraries=/usr/local/arm/2.95.3/arm-linux/usr/X11R6/lib

make

make DESTDIR=$ROOTFS_STAGING install

mv $ROOTFS_STAGING/usr/bin/arm-linux-sdl-config $BUILDDIR/

cd ..
