#!/bin/sh
#
# Author: Matthias Ihmig <m.ihmig@mytum.de>
# Last change: 6/25/2005
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU Library General Public License

set -e

[ -z "$MAKEROOTFS_CONFIG" ] && MAKEROOTFS_CONFIG=$PWD/makerootfs.conf
[ ! -e $MAKEROOTFS_CONFIG ] && echo "ERROR: Config file ($MAKEROOTFS_CONFIG) not found!" && exit
. $MAKEROOTFS_CONFIG

! which $TARGET_CC && echo "ERROR: Can't find $TARGET_CC in PATH!" && exit

FILE=fbv-1.0b.tar.gz
BASEURL=http://s-tech.elsat.net.pl/fbv/
SRCDIR=fbv-1.0b

echo === Building $FILE ===

cd $DOWNLOADS
[ ! -e "$FILE" ] && `$WGET $BASEURL$FILE`
cd $BUILDDIR
[ ! -e "$SRCDIR" ] && tar xvzf $DOWNLOADS/$FILE

cd $SRCDIR

#sed -i -e "s/= gcc/= $TARGET_CC/" Makefile

./configure --prefix=/usr --without-libungif --without-libpng --libs="-L$ROOTFS_STAGING/usr/lib"

make CFLAGS="-I$ROOTFS_STAGING/usr/include $TARGET_CFLAGS" CC=$TARGET_CC CPPFLAGS="-I$ROOTFS_STAGING/usr/include" LDFLAGS="-L$ROOTFS_STAGING/usr/lib"
make DESTDIR=$ROOTFS_STAGING install

cd ..
