#!/bin/bash
#
# Author: Matthias Ihmig <m.ihmig@mytum.de>
# Last change: 6/25/2005
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU Library General Public License

set -e

[ -z "$MAKEROOTFS_CONFIG" ] && MAKEROOTFS_CONFIG=$PWD/makerootfs.conf
[ ! -e $MAKEROOTFS_CONFIG ] && echo "ERROR: Config file ($MAKEROOTFS_CONFIG) not found!" && exit
. $MAKEROOTFS_CONFIG

! which $TARGET_CC && echo "ERROR: Can't find $TARGET_CC in PATH!" && exit

FILE=vlc-0.8.2.tar.gz
BASEURL=http://download.videolan.org/pub/vlc/0.8.2/
SRCDIR=vlc-0.8.2

echo === Building $FILE ===

cd $DOWNLOADS
[ ! -e "$FILE" ] && `$WGET $BASEURL$FILE`
cd $BUILDDIR
[ ! -e "$SRCDIR" ] && tar xvzf $DOWNLOADS/$FILE

cd $SRCDIR

# ./bootstrap
export VIDDIR="usr/share/vlc"
export PIXDIR="usr/share/pixmaps"
export DESTDIR=$ROOTFS_STAGING

export CONFIG_FLAGS="--enable-release --prefix=/usr \
        --disable-plugins \
	--disable-galaktos \
        --disable-gtk \
        --disable-gtk2 \
        --disable-gnome \
        --disable-gnome2 \
        --disable-qt \
        --disable-kde \
        --disable-xosd \
        --disable-ogg \
        --disable-tarkin \
        --disable-tremor \
        --disable-theorea \
	--disable-wxwindows \
        --disable-x11 \
	--disable-glx \
	--disable-opengl \
        --disable-xvideo \
        --disable-v4l \
	--disable-skins2 \
	--enable-ncurses \
        --enable-dummy \
        --enable-sout \
        --enable-fb \
        --enable-oss \
        --disable-alsa \
        --disable-dvd \
        --disable-dvdread \
        --disable-macosx --disable-qnx --disable-activex \
        --disable-freetype \
	--disable-joystick \
        --disable-mkv \
	--disable-libcdio --disable-libcddb --disable-cdda --disable-cddax \
	--disable-vcd --disable-vcdx \
        --enable-mad \
        --enable-ffmpeg \
        --enable-libmpeg2 \
        --disable-pda \
        --with-mad-tree=`ls -1 --color=none -d $BUILDDIR/libmad*` \
	--with-ffmpeg-tree=`ls -1 --color=none -d $BUILDDIR/ffmpeg*` \
	--with-libmpeg2-tree=`ls -1 --color=none -d $BUILDDIR/mpeg2dec*` \
	--with-sdl-config-path=$BUILDDIR \
	--with-sdl-prefix=$ROOTFS_STAGING/usr"

	# --with-twolame-tree=PATH twolame tree for static linking
	# --with-a52=PATH       a52 headers and libraries
	# --with-a52-tree=PATH  a52dec tree for static linking
	# --with-a52-fixed      specify if liba52 has been compiled with fixed point support
	# --with-dts-tree=PATH  libdts tree for static linking
	# --with-tarkin-tree=PATH tarkin tree for static linking
	# --with-x264-tree=PATH x264 tree for static linking
	# --with-qte=PATH       Qt Embedded headers and libraries
	# --with-faad-tree=PATH faad tree for static linking
	# --with-dvbpsi=PATH    libdvbpsi headers and libraries
	# --with-dvbpsi-tree=PATH libdvbpsi tree for static linking
	# --with-v4l=PATH       path to a v4l-enabled kernel tree
	# --with-dvb=PATH       path to a dvb- and v4l2-enabled kernel tree

./configure --host=$CROSS_HOST --target=$CROSS_HOST $CONFIG_FLAGS \
	--disable-rpath --disable-nls \
        LDFLAGS="-L$ROOTFS_STAGING/usr/lib" CPPFLAGS="-I$ROOTFS_STAGING/usr/include"
        #--disable-sdl
make

make DESTDIR=$ROOTFS_STAGING install
cd ..
