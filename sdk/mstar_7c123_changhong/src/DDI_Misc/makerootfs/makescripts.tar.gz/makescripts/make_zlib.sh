#!/bin/sh
#
# Author: Matthias Ihmig <m.ihmig@mytum.de>
# Last change: 6/25/2005
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU Library General Public License

set -e

[ -z "$MAKEROOTFS_CONFIG" ] && MAKEROOTFS_CONFIG=$PWD/makerootfs.conf
[ ! -e $MAKEROOTFS_CONFIG ] && echo "ERROR: Config file ($MAKEROOTFS_CONFIG) not found!" && exit
. $MAKEROOTFS_CONFIG

! which $TARGET_CC && echo "ERROR: Can't find $TARGET_CC in PATH!" && exit

FILE=zlib-1.2.3.tar.gz
BASEURL=http://download.sourceforge.net/libpng/
SRCDIR=zlib-1.2.3

echo === Building $FILE ===

cd $DOWNLOADS
[ ! -e "$FILE" ] && until `$WGET $BASEURL$FILE`; do sleep 1; done
cd $BUILDDIR
[ ! -e "$SRCDIR" ] && tar xvzf $DOWNLOADS/$FILE

cd $SRCDIR

CC=$TARGET_CC OBJCOPY=$CROSS_HOST-objcopy mandir=$ROOTFS_STAGING/usr/man ./configure --shared --prefix=/usr \
	--libdir=$ROOTFS_STAGING/usr/lib --includedir=$ROOTFS_STAGING/usr/include --exec-prefix=$ROOTFS_STAGING/usr/bin

make LDSHARED="$CROSS_HOST-gcc -shared -Wl,-soname,libz.so.1 --shared-libgcc" \
	CFLAGS="$TARGET_CFLAGS -fPIC" CC="$TARGET_CC" AR="$CROSS_HOST-ar" RANLIB="$CROSS_HOST-ranlib"
make install
cd ..

