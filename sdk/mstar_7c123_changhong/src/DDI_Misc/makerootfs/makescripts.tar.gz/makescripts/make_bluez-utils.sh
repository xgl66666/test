#!/bin/sh
#
# Author: Matthias Ihmig <m.ihmig@mytum.de>
# Last change: 6/25/2005
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU Library General Public License

set -e

[ -z "$MAKEROOTFS_CONFIG" ] && MAKEROOTFS_CONFIG=$PWD/makerootfs.conf
[ ! -e $MAKEROOTFS_CONFIG ] && echo "ERROR: Config file ($MAKEROOTFS_CONFIG) not found!" && exit
. $MAKEROOTFS_CONFIG

! which $TARGET_CC && echo "ERROR: Can't find $TARGET_CC in PATH!" && exit

FILE=bluez-utils-2.15.tar.gz
BASEURL=http://bluez.sourceforge.net/download/
SRCDIR=bluez-utils-2.15

echo === Building $FILE ===

cd $DOWNLOADS
[ ! -e "$FILE" ] && `$WGET $BASEURL$FILE`
cd $BUILDDIR
[ ! -e "$SRCDIR" ] && tar xvzf $DOWNLOADS/$FILE

cd $SRCDIR

# If you want to run getty to incoming rfcomm bluetooth connections, enable this patch
#
# [ ! -e $BUILDDIR/$SRCDIR/.patch_applied ] && patch -N -p1 < $PATCHES/bluez-utils-rfcomm.patch

mkdir -p $ROOTFS_STAGING/etc/bluetooth/rfcomm/
cp $PATCHES/bluez-utils-rfcomm.patch $ROOTFS_STAGING/etc/bluetooth/rfcomm/

[ ! -e $BUILDDIR/$SRCDIR/.patch_applied ] && patch -N -p1 < $PATCHES/bluez-utils-scripts.patch
touch $BUILDDIR/$SRCDIR/.patch_applied

CC=$TARGET_CC CFLAGS="$TARGET_CFLAGS -L$ROOTFS_STAGING/usr/lib" CPPFLAGS="-I$ROOTFS_STAGING/usr/include" LDFLAGS="-L$ROOTFS_STAGING/usr/lib" ./configure --host=$CROSS_HOST \
	--sysconfdir=/etc --localstatedir=/var \
 	--with-bluez=$ROOTFS_STAGING/usr --with-usb=$ROOTFS_STAGING/usr \
	--enable-test --enable-initscripts \
	--without-obex --without-dbus --without-cups --without-bluepin --disable-alsa

make

make DESTDIR=$ROOTFS_STAGING install

# The following changes originate from the gumstix-buildroot scripts
mkdir -p $ROOTFS_STAGING/etc/bluetooth/pan $ROOTFS_STAGING/etc/bluetooth/rfcomm
mkdir -p $ROOTFS_STAGING/etc/apm/scripts.d $ROOTFS_STAGING/etc/apm/resume.d $ROOTFS_STAGING/etc/apm/suspend.d
install -m 0755 $PATCHES/bluez-pand-devup.sh $ROOTFS_STAGING/etc/bluetooth/pan/dev-up
install -m 0755 $PATCHES/bluez-rfcomm-getty.sh $ROOTFS_STAGING/etc/bluetooth/rfcomm/rfcomm-getty
install -m 0755 $PATCHES/bluez-rfcomm-listen.sh $ROOTFS_STAGING/etc/bluetooth/rfcomm/rfcomm-listen
install -m 0755 $PATCHES/bluez-utils-pin-helper.bash $ROOTFS_STAGING/etc/bluetooth/pin-helper
install -m 0600 $PATCHES/bluez-pin $ROOTFS_STAGING/etc/bluetooth/pin
install -m 0755 $PATCHES/bluez-utils-bt-apm $ROOTFS_STAGING/etc/apm/scripts.d/bluetooth
ln -sf ../scripts.d/bluetooth $ROOTFS_STAGING/etc/apm/suspend.d/50bluetooth

rm $ROOTFS_STAGING/usr/bin/bluepin

mkdir -p $ROOTFS_STAGING/etc/init.d/run
ln -sf ../bluetooth $ROOTFS_STAGING/etc/init.d/run/S50bluetooth

cd ..
