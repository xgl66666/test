#!/bin/sh
#
# Author: Matthias Ihmig <m.ihmig@mytum.de>
# Last change: 6/25/2005
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU Library General Public License

set -e

[ -z "$MAKEROOTFS_CONFIG" ] && MAKEROOTFS_CONFIG=$PWD/makerootfs.conf
[ ! -e $MAKEROOTFS_CONFIG ] && echo "ERROR: Config file ($MAKEROOTFS_CONFIG) not found!" && exit
. $MAKEROOTFS_CONFIG

! which $TARGET_CC && echo "ERROR: Can't find $TARGET_CC in PATH!" && exit

FILE=dropbear-0.44.tar.bz2
BASEURL=http://matt.ucc.asn.au/dropbear/releases/
SRCDIR=dropbear-0.44
DROPBEAR_BINARY=dropbearmulti

echo === Building $FILE ===

cd $DOWNLOADS
[ ! -e "$FILE" ] && `$WGET $BASEURL$FILE`
cd $BUILDDIR
[ ! -e "$SRCDIR" ] && tar xvjf $DOWNLOADS/$FILE

cd $SRCDIR

[ ! -e $BUILDDIR/$SRCDIR/.patch_applied ] && patch -N -p1 < $PATCHES/dropbear-entropy.patch

autoconf
CC=$TARGET_CC LD=$TARGET_LD CFLAGS="$TARGET_CFLAGS" CPPFLAGS="-I$ROOTFS_STAGING/usr/include" LDFLAGS="-L$ROOTFS_STAGING/usr/lib" ./configure --host=$CROSS_HOST --disable-nls \
	--prefix=/usr --sysconfdir=/etc --localstatedir=/var --with-zlib=$ROOTFS_STAGING/usr/lib --with-shared \
	--disable-utmp --disable-lastlog --disable-utmp --disable-utmpx --disable-wtmp --disable-wtmpx --disable-zlib

make CC=$TARGET_CC LD=$TARGET_CC SCPPROGRESS=1 MULTI=1 PROGRAMS="ssh scp dropbear dbclient dropbearkey dropbearconvert"

mkdir -p $ROOTFS_STAGING/etc/dropbear/ $ROOTFS_STAGING/etc/init.d/run
touch $ROOTFS_STAGING/etc/dropbear/tiny_ssh_replacement
install -m 0755 $PATCHES/dropbear-sshd-init $ROOTFS_STAGING/etc/init.d/sshd
ln -sf ../sshd  $ROOTFS_STAGING/etc/init.d/run/S60sshd

install -d -m 755 $ROOTFS_STAGING/usr/sbin
install -d -m 755 $ROOTFS_STAGING/usr/bin
install -m 755 $DROPBEAR_BINARY $ROOTFS_STAGING/usr/sbin

ln -sf ./$DROPBEAR_BINARY $ROOTFS_STAGING/usr/sbin/dropbear
ln -sf ./$DROPBEAR_BINARY $ROOTFS_STAGING/usr/sbin/dropbearkey
ln -sf ./$DROPBEAR_BINARY $ROOTFS_STAGING/usr/sbin/dropbearconvert
ln -sf ../sbin/$DROPBEAR_BINARY $ROOTFS_STAGING/usr/bin/dbclient
ln -sf ../sbin/$DROPBEAR_BINARY $ROOTFS_STAGING/usr/bin/ssh
ln -sf ../sbin/$DROPBEAR_BINARY $ROOTFS_STAGING/usr/bin/scp

cd ..
