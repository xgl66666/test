#!/bin/bash
#
# Author: Matthias Ihmig <m.ihmig@mytum.de>
# Last change: 6/25/2005
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU Library General Public License

set -e

[ -z "$MAKEROOTFS_CONFIG" ] && MAKEROOTFS_CONFIG=$PWD/makerootfs.conf
[ ! -e $MAKEROOTFS_CONFIG ] && echo "ERROR: Config file ($MAKEROOTFS_CONFIG) not found!" && exit
. $MAKEROOTFS_CONFIG

! which $TARGET_CC && echo "ERROR: Can't find $TARGET_CC in PATH!" && exit

FILE=ffmpeg-0.4.9-pre1.tar.gz
BASEURL=http://download.sourceforge.net/ffmpeg/
SRCDIR=ffmpeg-0.4.9-pre1

echo === Building $FILE ===

cd $DOWNLOADS
[ ! -e "$FILE" ] && until `$WGET $BASEURL$FILE`; do sleep 1; done
cd $BUILDDIR
[ ! -e "$SRCDIR" ] && tar xvzf $DOWNLOADS/$FILE

cd $SRCDIR

#	CFLAGS="$TARGET_CFLAGS -I$ROOTFS_STAGING/usr/include -L$ROOTFS_STAGING/usr/lib" LDFLAGS="-L$ROOTFS_STAGING/usr/lib" CPPFLAGS="-I$ROOTFS_STAGING/usr/include" \
./configure --host=$CROSS_HOST --cpu=arm4l -cc=$TARGET_CC --disable-mmx --disable-audio-beos \
	--disable-altivec --disable-v4l --disable-dv1349 --disable-vhook --disable-debug \
	--prefix=$ROOTFS_STAGING/usr --sysconfdir=/etc \
	--enable-shared --enable-pp --enable-gpl  \
	--cross-prefix=$CROSS_HOST- --extra-cflags="$TARGET_CFLAGS  -L$ROOTFS_STAGING/usr/lib -I$ROOTFS_STAGING/usr/include" \
	--extra-ldflags="-L$ROOTFS_STAGING/usr/lib" --extra-libs="-L$ROOTFS_STAGING/usr/lib -ldl"

# cd libavcodec

make

grep -l "install -s" `find .` | xargs -r -l1 sed -i -e "s/install -s/install/"
grep -l "install -c -s" `find .` | xargs -r -l1 sed -i -e "s/install -c -s/install -c/"
make install
cd ..
