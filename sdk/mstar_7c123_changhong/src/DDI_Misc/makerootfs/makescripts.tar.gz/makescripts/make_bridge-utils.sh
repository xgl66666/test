#!/bin/bash
#
# Author: Matthias Ihmig <m.ihmig@mytum.de>
# Last change: 6/25/2005
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU Library General Public License

set -e

[ -z "$MAKEROOTFS_CONFIG" ] && MAKEROOTFS_CONFIG=$PWD/makerootfs.conf
[ ! -e $MAKEROOTFS_CONFIG ] && echo "ERROR: Config file ($MAKEROOTFS_CONFIG) not found!" && exit
. $MAKEROOTFS_CONFIG

! which $TARGET_CC && echo "ERROR: Can't find $TARGET_CC in PATH!" && exit

FILE=bridge-utils-1.0.6.tar.gz
BASEURL=http://download.sourceforge.net/bridge/
SRCDIR=bridge-utils-1.0.6

echo === Building $FILE ===

cd $DOWNLOADS
[ ! -e "$FILE" ] && until `$WGET $BASEURL$FILE`; do sleep 1; done

cd $BUILDDIR
[ ! -e "$SRCDIR" ] && tar xvzf $DOWNLOADS/$FILE

cd $SRCDIR

[ ! -e $BUILDDIR/$SRCDIR/.patch_applied ] && patch -N -p1 < $PATCHES/bridge-cflags.patch
touch $BUILDDIR/$SRCDIR/.patch_applied

CC=$TARGET_CC CFLAGS="$TARGET_CFLAGS" CPPFLAGS="-I$ROOTFS_STAGING/usr/include" LDFLAGS="-L$ROOTFS_STAGING/usr/lib" ./configure --host=$CROSS_HOST --prefix=/usr --localstatedir=/var \
	--disable-nls --with-linux=$KERNEL_PATH

make
make DESTDIR=$ROOTFS_STAGING install
cd ..

