#!/bin/sh
#
# Author: Matthias Ihmig <m.ihmig@mytum.de>
# Last change: 6/25/2005
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU Library General Public License

set -e

[ -z "$MAKEROOTFS_CONFIG" ] && MAKEROOTFS_CONFIG=$PWD/makerootfs.conf
[ ! -e $MAKEROOTFS_CONFIG ] && echo "ERROR: Config file ($MAKEROOTFS_CONFIG) not found!" && exit
. $MAKEROOTFS_CONFIG

! which $TARGET_CC && echo "ERROR: Can't find $TARGET_CC in PATH!" && exit

FILE=apmd_3.2.2.orig.tar.gz
BASEURL=http://ftp.debian.org/debian/pool/main/a/apmd/
SRCDIR=apmd-3.2.2.orig

echo === Building $FILE ===

cd $DOWNLOADS
[ ! -e "$FILE" ] && `$WGET $BASEURL$FILE`
cd $BUILDDIR
[ ! -e "$SRCDIR" ] && tar xvzf $DOWNLOADS/$FILE

cd $SRCDIR

[ ! -e $BUILDDIR/$SRCDIR/.patch_applied ] && patch -N -p1 < $PATCHES/apm-makefile.patch
touch $BUILDDIR/$SRCDIR/.patch_applied

make HOST=$CROSS_HOST CC=$TARGET_CC CFLAGS="$TARGET_CFLAGS" RANLIB="$CROSS_HOST-ranlib" LIBTOOL="$BUILDDIR/$CROSS_HOST-libtool" apm apmd

echo "*** installing"
make HOST=$CROSS_HOST CC=$TARGET_CC CFLAGS="$TARGET_CFLAGS" RANLIB="$CROSS_HOST-ranlib" LIBTOOL="$BUILDDIR/$CROSS_HOST-libtool" DESTDIR=$ROOTFS_STAGING install

mkdir -p $ROOTFS_STAGING/var/run/
mkdir -p $ROOTFS_STAGING/etc/apm/
install -m 0755 $PATCHES/apm-apmd_proxy $ROOTFS_STAGING/etc/apm/apmd_proxy

cd $ROOTFS_STAGING/etc/apm/
mkdir -p event.d other.d resume.d scripts.d suspend.d

install -m 0755 $PATCHES/apm-ifupdown-script scripts.d/ifupdown
ln -sf ../scripts.d/ifupdown resume.d/30ifupdown && echo -n
ln -sf ../scripts.d/ifupdown suspend.d/05ifupdown && echo -n

mkdir -p $ROOTFS_STAGING/etc/default/ $ROOTFS_STAGING/etc/init.d/run
install -m 0644 $PATCHES/apm-apmd.conf $ROOTFS_STAGING/etc/default/apmd
install -m 0755 $PATCHES/apm-apmd-initd $ROOTFS_STAGING/etc/init.d/apmd
ln -sf ../apmd $ROOTFS_STAGING/etc/init.d/run/S30apmd

cd ..


