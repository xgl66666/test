#!/bin/bash
#
# Author: Matthias Ihmig <m.ihmig@mytum.de>
# Last change: 6/25/2005
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU Library General Public License

set -e

[ -z "$MAKEROOTFS_CONFIG" ] && MAKEROOTFS_CONFIG=$PWD/makerootfs.conf
[ ! -e $MAKEROOTFS_CONFIG ] && echo "ERROR: Config file ($MAKEROOTFS_CONFIG) not found!" && exit
. $MAKEROOTFS_CONFIG

! which $TARGET_CC && echo "ERROR: Can't find $TARGET_CC in PATH!" && exit

FILE=ser2net-2.2.tar.gz
BASEURL=http://download.sourceforge.net/ser2net/
SRCDIR=ser2net-2.2

echo === Building $FILE ===

cd $DOWNLOADS
[ ! -e "$FILE" ] && until `$WGET $BASEURL$FILE`; do sleep 1; done
cd $BUILDDIR
[ ! -e "$SRCDIR" ] && tar xvzf $DOWNLOADS/$FILE

cd $SRCDIR

CFLAGS="$TARGET_CFLAGS" ./configure --host=$CROSS_HOST --prefix=/usr

make
make DESTDIR=$ROOTFS_STAGING install

mkdir -p $ROOTFS_STAGING/etc/
install -m 0644 $PATCHES/ser2net.conf $ROOTFS_STAGING/etc/

cd ..

