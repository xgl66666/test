#!/bin/bash
#
# Author: Matthias Ihmig <m.ihmig@mytum.de>
# Last change: 6/25/2005
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU Library General Public License

set -e

[ -z "$MAKEROOTFS_CONFIG" ] && MAKEROOTFS_CONFIG=$PWD/makerootfs.conf
[ ! -e $MAKEROOTFS_CONFIG ] && echo "ERROR: Config file ($MAKEROOTFS_CONFIG) not found!" && exit
. $MAKEROOTFS_CONFIG

! which $TARGET_CC && echo "ERROR: Can't find $TARGET_CC in PATH!" && exit

FILE=usbutils-0.71.tar.gz
BASEURL=http://download.sourceforge.net/linux-usb/
SRCDIR=usbutils-0.71

echo === Building $FILE ===

cd $DOWNLOADS
[ ! -e "$FILE" ] && until `$WGET $BASEURL$FILE`; do sleep 1; done
cd $BUILDDIR
[ ! -e "$SRCDIR" ] && tar xvzf $DOWNLOADS/$FILE

cd $SRCDIR

CC=$TARGET_CC CFLAGS="$TARGET_CFLAGS -I$ROOTFS_STAGING/usr/include -L$ROOTFS_STAGING/usr/lib" LDFLAGS="-L$ROOTFS_STAGING/usr/lib" CPPFLAGS="-I$ROOTFS_STAGING/usr/include" ./configure --host=$CROSS_HOST --build=i386-linux --prefix=/usr --sysconfdir=/etc

# rpl_malloc workaround
sed -i -e "s/#define malloc rpl_malloc/\/*#define malloc rpl_malloc*\//" config.h

make
make DESTDIR=$ROOTFS_STAGING install

mkdir -p $ROOTFS_STAGING/etc/init.d $ROOTFS_STAGING/etc/conf.d
mkdir -p $ROOTFS_STAGING/etc/apm/scripts.d $ROOTFS_STAGING/etc/apm/resume.d $ROOTFS_STAGING/etc/apm/suspend.d
install -m 0755 $PATCHES/usbutils-usbg_ether-initd $ROOTFS_STAGING/etc/init.d/usbg_ether
install -m 0644 $PATCHES/usbutils-usb-confd $ROOTFS_STAGING/etc/conf.d/usb
install -m 0755 $PATCHES/usbutils-usbnet-apm $ROOTFS_STAGING/etc/apm/scripts.d/usbnet
ln -sf ../scripts.d/usbnet $ROOTFS_STAGING/etc/apm/resume.d/10usbnet
ln -sf ../scripts.d/usbnet $ROOTFS_STAGING/etc/apm/suspend.d/10usbnet

cd ..

