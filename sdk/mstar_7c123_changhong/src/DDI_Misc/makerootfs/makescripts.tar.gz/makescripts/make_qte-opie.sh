#!/bin/bash
#
# Author: Matthias Ihmig <m.ihmig@mytum.de>
# Last change: 6/25/2005
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU Library General Public License
#
# This is a download- and build script to (hopefully) make building of qt and opie easier
#
# libjpeg zlib tslib libpcap and sqlite3 must be present to build QT/OPIE !
# Make sure these (along with other optional libraries) are available
# in $ROOTFS_STAGING/usr/lib (other libraries may e.g. come from an openembedded or manual build)

set -e

[ -z "$MAKEROOTFS_CONFIG" ] && MAKEROOTFS_CONFIG=$PWD/makerootfs.conf
[ ! -e $MAKEROOTFS_CONFIG ] && echo "ERROR: Config file ($MAKEROOTFS_CONFIG) not found!" && exit
. $MAKEROOTFS_CONFIG

! which $TARGET_CC && echo "ERROR: Can't find $TARGET_CC in PATH!" && exit

cd $BUILDDIR

export QTDIR=$PWD/qt-$QTVER

QTGETVER=$QTVER
[ "$QTVER" == "2.3.10" ] && QTGETVER="$QTGETVER-free"

export OPIEDIR=$PWD/opie
[ -n "$OPIEVER" ] && OPIEDIR="$OPIEDIR-$OPIEVER"

([ "$OPIEVER" == "1.0.3" ] || [ "$OPIEVER" == "1.2.0" ] ) && OPIEDIST=stable
([ "$OPIEVER" == "1.1.8" ] || [ "$OPIEVER" == "1.1.9" ] ) && OPIEDIST=testing
OPIEURL_DIR=http://opie.handhelds.org/feed/source/$OPIEDIST

[ "$OPIEDIST" == "testing" ] && OPIEURL_FILE="opie-source_$OPIEVER.tar.bz2"
[ "$OPIEDIST" == "stable"  ] && OPIEURL_FILE="opie-source-$OPIEVER.tar.bz2"

echo "===== QT version     $QTVER"
echo "===== OPIE version   $OPIEVER"
echo "===== ROOTFS_STAGING $ROOTFS_STAGING"
echo "===== DOWNLOADS      $DOWNLOADS"
echo "===== PATCHES        $PATCHES"
echo "===== QTDIR          $QTDIR"
echo "===== OPIEDIR        $OPIEDIR"

if [ ! -d "$QTDIR" ]
then
    echo "=============="
    echo "============== Downloading and extracting  QT-Embedded $QTGETVER ==========="
    [ ! -e "$DOWNLOADS/uic-qt2" ] && wget -N http://vanille.de/tools/uic-qt2 -P $DOWNLOADS && chmod ugo+x $DOWNLOADS/uic-qt2

    [ ! -e "$DOWNLOADS/qt-embedded-$QTGETVER.tar.gz" ] && wget -N ftp://ftp.trolltech.com/pub/qt/source/qt-embedded-$QTGETVER.tar.gz -P $DOWNLOADS
    echo "Extracting qt-embedded-$QTGETVER.tar.gz..." && tar xzf $DOWNLOADS/qt-embedded-$QTGETVER.tar.gz

# Install a few more fonts
    if [ ! -e "$DOWNLOADS/qpf-fonts.tar.gz" ]
    then
	TMP=$PWD ; cd $DOWNLOADS
    	wget http://www.openzaurus.org/official/unstable/3.5.2/feed/opie/qpf-bitstream-vera-large_1.10-r0_arm.ipk
    	wget http://www.openzaurus.org/official/unstable/3.5.2/feed/opie/qpf-bitstream-vera-sans-mono-huge_1.10-r0_arm.ipk
    	wget http://www.openzaurus.org/official/unstable/3.5.2/feed/opie/qpf-bitstream-vera-sans-mono-large_1.10-r0_arm.ipk
    	wget http://www.openzaurus.org/official/unstable/3.5.2/feed/opie/qpf-bitstream-vera-sans-mono-small_1.10-r0_arm.ipk
    	wget http://www.openzaurus.org/official/unstable/3.5.2/feed/opie/qpf-bitstream-vera-small_1.10-r0_arm.ipk
    	#wget http://www.openzaurus.org/official/unstable/3.5.2/feed/opie/qpf-georgia-large_1.0-r0_all.ipk
    	#wget http://www.openzaurus.org/official/unstable/3.5.2/feed/opie/qpf-georgia-small_1.0-r0_all.ipk
    	#wget http://www.openzaurus.org/official/unstable/3.5.2/feed/opie/qpf-helvetica-large_1.0-r0_all.ipk
    	#wget http://www.openzaurus.org/official/unstable/3.5.2/feed/opie/qpf-helvetica-small_1.0-r0_all.ipk
    	#wget http://www.openzaurus.org/official/unstable/3.5.2/feed/opie/qpf-unifont_1.0-r0_all.ipk
    	#wget http://www.openzaurus.org/official/unstable/3.5.2/feed/opie/qpf-utopia-large_1.0-r0_all.ipk
    	#wget http://www.openzaurus.org/official/unstable/3.5.2/feed/opie/qpf-utopia-small_1.0-r0_all.ipk
    	#wget http://www.openzaurus.org/official/unstable/3.5.2/feed/opie/qpf-verdana-large_1.0-r0_all.ipk
    	#wget http://www.openzaurus.org/official/unstable/3.5.2/feed/opie/qpf-verdana-small_1.0-r0_all.ipk

	echo "==== extracting fonts"
	ls -1 --color=no | grep -E '(.ipk)$' | xargs -l1 -i{} bash -c "echo {} ; ar x {} ; mv data.tar.gz {}.tar.gz"
	ls -1 --color=no | grep -E '(.ipk.tar.gz)$' | xargs -l1 -t -i{} bash -c "tar xfvz {}"
	rm *.ipk control.tar.gz debian-binary
	mv opt/QtPalmtop/lib/fonts/ fonts/
	rm -rf opt/
	tar cfvz qpf-fonts.tar.gz fonts/
	rm -rf fonts/
	cd $TMP
    fi
    echo "=============="
    echo "============== Extracting bitstream-vera font familiy ==========="

    # use previously packed fonts
    [ -e "$DOWNLOADS/qpf-fonts.tar.gz" ] && tar xfvz "$DOWNLOADS/qpf-fonts.tar.gz" -C $QTDIR/lib/
fi

if [ ! -d "$OPIEDIR" ] || [ -z "$OPIEVER" ]
then
    echo "==============="
    if [ -z "$OPIEVER" ]
    then
    echo "=============== Downloading/Updating Opie from CVS,     Password anoncvs       ==============="
    echo "=============== Just press Enter if you want to use a previously downloaded snapshot from opie-cvs.tar.gz"

       if cvs -d:pserver:anoncvs@cvs.handhelds.org:/cvs login
       then
          [ ! -d opie ] && cvs -z3 -d:pserver:anoncvs@cvs.handhelds.org:/cvs co opie && cp $PATCHES/opie-cvs-default.config $OPIEDIR/.config
          cd opie
          cvs -z3 update -dP
          cvs logout
          cd ..
	  cp $PATCHES/opie-cvs-default.config $OPIEDIR/.config
       else
          [ ! -d "$OPIEDIR" ] && tar xfz $PATCHES/opie-cvs.tar.gz && cp $PATCHES/opie-cvs-default.config $OPIEDIR/.config
       fi

    else
       echo "=============== Downloading/Extracting Opie from opie.handhelds.org *****"
       [ ! -e "$DOWNLOADS/$OPIEURL_FILE" ] && wget -N "$OPIEURL_DIR/$OPIEURL_FILE" -P $DOWNLOADS
       echo "Extracting $OPIEURL_FILE..." && tar xjf $DOWNLOADS/$OPIEURL_FILE
       cp $PATCHES/opie-$OPIEVER-default.config $OPIEDIR/.config
    fi
    sed -i -e "s:/tftp/fs/usr/:$ROOTFS_STAGING/usr/:" $OPIEDIR/.config
fi

if [ ! -e "$QTDIR/.OPIE_QTE_PATCHES_APPLIED" ]
then
    echo "==============="
    echo "=============== Applying patches to QT-Embedded qt-$QTVER ==============="
    cd $QTDIR
    PT="$OPIEDIR/qt/qt-$QTVER.patch"
    [ $QTVER == 2.3.7 ]  && patch -N -p1 < $PT/qte237-all.patch
    [ $QTVER == 2.3.8 ]  && patch -N -p1 < $PT/qte238-all.patch && patch -N -p1 < $PATCHES/qte238-tslib.patch
    [ $QTVER == 2.3.9 ]  && patch -N -p1 < $PT/qte239-all.patch
    [ $QTVER == 2.3.10 ] && patch -N -p1 < $PT/qte-2.3.10-all.patch && patch -N -p1 < $PT/tslib.patch
    cd ..

    rm -f $QTDIR/src/tools/qconfig-qpe.h
    ln -sf $OPIEDIR/qt/qconfig-qpe.h $QTDIR/src/tools/

    mkdir -p $QTDIR/bin
    rm -f $QTDIR/bin/uic
    ln -sf $DOWNLOADS/uic-qt2 $QTDIR/bin/uic
    touch $QTDIR/.OPIE_QTE_PATCHES_APPLIED
fi

if [ ! -e "$OPIEDIR/.OPIE_PATCHES_APPLIED" ]
then
    echo "==============="
    echo "=============== Applying patches to opie-$OPIEVER ==============="
    cd $OPIEDIR
    [ $OPIEVER == 1.2.0 ]  && patch -N -p1 < $PATCHES/opie-1.2.0-bluetooth.patch \
	&& patch -N -p1 < $PATCHES/opie-1.2.0-mkipks.patch \
	&& cp $PATCHES/opie-1.2.0-btdefconfig.in noncore/net/opietooth/config.in

    # Replace Wireless Extensions v16 by WE-17
    mkdir -p include/linux
    [ -e $PATCHES/wireless.h ] && cp $PATCHES/wireless.h include/linux/
#    # Extract ipkg libraries&includes
#    [ -e $PATCHES/libipkg-dev.tar.gz ] && tar xfvz $PATCHES/libipkg-dev.tar.gz -C $MYROOTFS

#    # Extract ssl libraries&includes (required only for rdesktop client)
#    [ -e $PATCHES/openssl-dev.tar.gz ] && tar xfvz $PATCHES/openssl-dev.tar.gz -C $OPIEDIR

    # Additional control file fixes for make ipks
    cp apps/Applications/sysinfo.desktop apps/Settings/sysinfo.desktop
    cp apps/Unsupported/ubrowser.desktop apps/Applications/ubrowser.desktop

    cp noncore/tools/opie-sh/scripts/*.sh bin/
    patch -N -p1 < $PATCHES/opie-initd.patch

    cd ..

    touch $OPIEDIR/.OPIE_PATCHES_APPLIED
fi

echo "==============="
echo "=============== Creating set-opie-env.sh. Source it if you want to run make opie later by hand  ==============="

cat > set-opie-env.sh<< EOF
# Source this if you want to make opie later manually again
export QTDIR="$QTDIR"
export OPIEDIR="$OPIEDIR"
export PATH="\$QTDIR/bin:\$OPIEDIR/bin:\$PATH"
export LD_LIBRARY_PATH="\$QTDIR/lib:\$OPIEDIR/lib:$ROOTFS_STAGING/usr/lib:\$LD_LIBRARY_PATH"
EOF

echo "==============="
echo "=============== Creating prepare-opie-install.sh. Use this after a successful opie make to get ipks and install files ==============="

cat > prepare-opie-install.sh<< EOF
#!/bin/sh
# Use this script after a successful opie-make to get ipks and install files into _install
# Questions and comments to: Matthias Ihmig, m.ihmig@mytum.de

set -e

unset LD_LIBRARY_PATH
export QTDIR="$QTDIR"
export OPIEDIR="$OPIEDIR"
export PATH="\$QTDIR/bin:\$OPIEDIR/bin:\$PATH"
export QTE_BASEVERSION=$QTVER

cd $OPIEDIR

[ ! "$1" = "noipks" ] && echo "===== Making IPKs" && make ipks
#./mkipks

rm -rf _install/
mkdir _install
echo "==== extract data.tar.gz from ipks to _install/*.tar.gz"
ls -1 --color=no | grep -E '(.ipk)$' | xargs -l1 -i{} bash -c "echo {} ; ar x {} ; mv data.tar.gz _install/{}.tar.gz"
cd _install
echo "==== unpack tar.gz packages into _install"
ls -1 --color=no | grep -E '(.ipk.tar.gz)$' | xargs -l1 -t -i{} bash -c "tar xfvz {}"

# make key & screen clicks work by installing sound server daemon
install -m 0755 ../bin/qss opt/QtPalmtop/bin/qss

EOF
chmod ugo+x prepare-opie-install.sh

export PATH="$QTDIR/bin:$OPIEDIR/bin:$PATH"
export LD_LIBRARY_PATH="$QTDIR/lib:$OPIEDIR/lib:$MYROOTFS/usr/lib:$LD_LIBRARY_PATH"

echo "==============="
echo "=============== Configuring QT-Embedded $QTVER (only if not yet successful) ==============="
cd $QTDIR
[ ! -e "$QTDIR/.CONFIGURE_SUCCESSFUL" ] && echo yes | ./configure -gif -thread -tslib -system-jpeg -no-xft -xplatform linux-arm-g++ -I$ROOTFS_STAGING/usr/include -L$ROOTFS_STAGING/usr/lib -qconfig qpe -depths 16,24 -no-qvfb -keypad-mode && touch $QTDIR/.CONFIGURE_SUCCESSFUL

echo "=============== The Qt library will be built in ./lib"
echo "=============== The Qt examples are in ./examples"
echo "=============== The Qt tutorials are in ./tutorial"

if [ ! -e "$QTDIR/.MAKE_SUCCESSFUL" ]
then
   echo "=============== Making QT-Embedded $QTVER and copying libraries  ============================"
   make
   touch $QTDIR/.MAKE_SUCCESSFUL
   [ -h $QTDIR/lib/libts-0.0.so.0  ] && rm $QTDIR/lib/libts-0.0.so.0
   [ -h $QTDIR/lib/libjpeg.so.62   ] && rm $QTDIR/lib/libjpeg.so.62
   cp -a $ROOTFS_STAGING/usr/lib/lib* $QTDIR/lib/
   # cp -a $QTDIR/lib/lib* $ROOTFS_STAGING/usr/lib/

# Better use qpf-fonts; smaller files!
#   [ ! -d "$MYROOTFS/usr/lib/fonts" ] && mkdir -p $MYROOTFS/usr/lib/fonts && cp -a $QTDIR/lib/fonts/* $MYROOTFS/usr/lib/fonts/

fi
cd ..

echo "==============="
echo "=============== Configuring Opie $OPIEVER ==============="
cd $OPIEDIR

#echo =============== In menuconfig,
#echo ===============  - selet Target Machine: Sharp Zaurus with PXA25x
#echo ===============  - Save configuration
#echo ===============  - Load configuration
#echo ===============  - select different Target Machine: Sharp Zaurus with SA1100
#echo =============== Now check if the compile flags are still the PXA25x ones
#echo ===============     -march=armv5te -mtune=xscale -mapcs-32 -fexpensive-optimizations -fomit-frame-pointer -fpermissive -O2
#echo =============== Then exit
#echo ===============

#make menuconfig
CFLAGS_EXTRA="-I$ROOTFS_STAGING/usr/include" LFLAGS_EXTRA="-L$ROOTFS_STAGING/usr/lib" make oldconfig

echo "==============="
echo "=============== Making Opie $OPIEVER  ==============="

CFLAGS_EXTRA="-I$ROOTFS_STAGING/usr/include" LFLAGS_EXTRA="-L$ROOTFS_STAGING/usr/lib" make

cd ..

echo "==============="
echo "=============== Finished. Now running ./prepare-opie-install.sh to get _install tree"

./prepare-opie-install.sh

echo "=============== Installing OPIE into $ROOTFS_STAGING/ "
cd $OPIEDIR/_install
  mkdir -p $ROOTFS_STAGING/etc/ppp/peers
  cp -a etc/ppp/peers/* $ROOTFS_STAGING/etc/ppp/peers

  mkdir -p $ROOTFS_STAGING/etc/apm/resume.d $ROOTFS_STAGING/etc/apm/suspend.d
  cp -a etc/resume-scripts/R46opiealarm $ROOTFS_STAGING/etc/apm/resume.d/46opiealarm
  cp -a etc/suspend-scripts/S46opiealarm $ROOTFS_STAGING/etc/apm/suspend.d/46opiealarm

  rm -rf $ROOTFS_STAGING/opt
  cp -a opt/ $ROOTFS_STAGING/opt

  install -m 0755 usr/bin/changedns $ROOTFS_STAGING/usr/bin/
  install -m 0755 usr/sbin/update-qtfontdir $ROOTFS_STAGING/usr/sbin/

  # workaround for broken sort -u in busybox
  sed -i -e "s:sort -u:sort:" $ROOTFS_STAGING/usr/sbin/update-qtfontdir

ln -sf $OPIEDIR/_install/usr/share/zoneinfo $BUILDDIR/zoneinfo

cd $OPIEDIR/root
  mkdir -p $ROOTFS_STAGING/etc/apm/event.d
  cp -a etc/apm/event.d/0* $ROOTFS_STAGING/etc/apm/event.d

  mkdir -p $ROOTFS_STAGING/etc/init.d
  install -m 0755 etc/init.d/bootsplash $ROOTFS_STAGING/etc/init.d
  install -m 0755 etc/init.d/opie $ROOTFS_STAGING/etc/init.d

  mkdir -p $ROOTFS_STAGING/etc/ppp/scripts
  install -m 0644 etc/ppp/scripts/winclient.chat $ROOTFS_STAGING/etc/ppp/scripts

  install -m 0644 opt/QtPalmtop/etc/opie-login.conf $ROOTFS_STAGING/opt/QtPalmtop/etc/

install -m 0644 $PATCHES/opie-profile-qpe $ROOTFS_STAGING/etc/profile-qpe

echo "*** Done."
