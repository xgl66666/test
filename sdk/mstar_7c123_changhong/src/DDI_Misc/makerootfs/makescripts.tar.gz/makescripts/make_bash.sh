#!/bin/bash
#
# Author: Matthias Ihmig <m.ihmig@mytum.de>
# Last change: 6/25/2005
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU Library General Public License

set -e

[ -z "$MAKEROOTFS_CONFIG" ] && MAKEROOTFS_CONFIG=$PWD/makerootfs.conf
[ ! -e $MAKEROOTFS_CONFIG ] && echo "ERROR: Config file ($MAKEROOTFS_CONFIG) not found!" && exit
. $MAKEROOTFS_CONFIG

! which $TARGET_CC && echo "ERROR: Can't find $TARGET_CC in PATH!" && exit

FILE=bash-2.05a.tar.gz
BASEURL=ftp://ftp.gnu.org/gnu/bash/
SRCDIR=bash-2.05a

echo === Building $FILE ===

cd $DOWNLOADS
[ ! -e "$FILE" ] && `$WGET $BASEURL$FILE`
cd $BUILDDIR
[ ! -e "$SRCDIR" ] && tar xvzf $DOWNLOADS/$FILE

cd $SRCDIR

[ ! -e $BUILDDIR/$SRCDIR/.patch_applied ] && patch -N -p1 < $PATCHES/bash-2.05a-bashversion.patch
touch $BUILDDIR/$SRCDIR/.patch_applied

ac_cv_sys_restartable_syscalls=yes \
ac_cv_func_setvbuf_reversed=no \
bash_cv_have_mbstate_t=yes \
CC=$TARGET_CC LD=$TARGET_LD CC_FOR_BUILD=$HOSTCC CFLAGS="$TARGET_CFLAGS -L$ROOTFS_STAGING/usr/lib" \
CPPFLAGS="-I$ROOTFS_STAGING/usr/include" LDFLAGS="-L$ROOTFS_STAGING/usr/lib" \
	./configure --build=i386-linux --host=$CROSS_HOST --target=$CROSS_HOST \
		--prefix=$ROOTFS_STAGING --enable-readline --with-curses --enable-alias \
		--without-bash-malloc --disable-nls

make CC=$TARGET_CC LD=$TARGET_LD CC_FOR_BUILD=$HOSTCC
make install prefix=$ROOTFS_STAGING

rm -f $ROOTFS_STAGING/bin/bashbug $ROOTFS_STAGING/info/bash.info $ROOTFS_STAGING/info/dir
rmdir $ROOTFS_STAGING/info && echo -n

echo
echo " *** Note that the installed binaries are not stripped automatically so you may have to do it manually by using $TARGET_STRIP."
echo
cd ..

# If you get the error message unknown option --dir-file your texinfo installation is pretty old.
# This may happen if you are running Debian GNU/Linux. If you can't (or don't want to) update
# your texinfo installation you can do this: Edit the file doc/Makefile.in and search for this part:

# install-info --dir-file=$(DESTDIR)$(infodir)/dir $(DESTDIR)$(infodir)/bash.info; \

# And modify it so it looks like this:

# install-info --info-dir=$(DESTDIR)$(infodir) $(DESTDIR)$(infodir)/bash.info; \

# Now you need to add a dummy dir-file file if it's not already present:

#     echo 1 > <root-directory>/info/dir

# Now run the above configure command again so the Makefile is regenerated.
# Now the call to make install should work like a charm.
