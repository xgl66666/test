#!/bin/bash
#
# Author: Matthias Ihmig <m.ihmig@mytum.de>
# Last change: 6/25/2005
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU Library General Public License

set -e

[ -z "$MAKEROOTFS_CONFIG" ] && MAKEROOTFS_CONFIG=$PWD/makerootfs.conf
[ ! -e $MAKEROOTFS_CONFIG ] && echo "ERROR: Config file ($MAKEROOTFS_CONFIG) not found!" && exit
. $MAKEROOTFS_CONFIG

! which $TARGET_CC && echo "ERROR: Can't find $TARGET_CC in PATH!" && exit

FILE=sqlite-3.2.1.tar.gz
BASEURL=http://www.hwaci.com/sw/sqlite/
SRCDIR=sqlite-3.2.1

echo === Building $FILE ===

cd $DOWNLOADS
[ ! -e "$FILE" ] && `$WGET $BASEURL$FILE`
cd $BUILDDIR
[ ! -e "$SRCDIR" ] && tar xvzf $DOWNLOADS/$FILE

cd $SRCDIR

[ ! -e $BUILDDIR/$SRCDIR/.patch_applied ] && patch -N -p1 < $PATCHES/sqlite-3.2.1-configure.patch
touch $BUILDDIR/$SRCDIR/.patch_applied

	CC=$TARGET_CC LD=$TARGET_LD
	config_BUILD_CC=$HOSTCC \
	config_TARGET_CFLAGS="$TARGET_CFLAGS" config_TARGET_CC=$TARGET_CC \
	config_TARGET_READLINE_LIBS="-L$ROOTFS_STAGING/usr/lib -L$ROOTFS_STAGING/lib -lncurses -lreadline" \
	config_TARGET_READLINE_INC="-I$ROOTFS_STAGING/usr/include" \
./configure --prefix=/usr --host=$CROSS_HOST \
		--with-gnu-ld \
		--disable-tcl \
		--enable-shared \
		--enable-static \
		--enable-tempstore \
		--enable-threadsafe \
		--enable-releasemode

patch -N -p1 < $PATCHES/sqlite-3.2.1-makefile.patch && echo

make
make prefix=$ROOTFS_STAGING/usr install

cd ..

