#!/bin/sh
#
# Author: Matthias Ihmig <m.ihmig@mytum.de>
# Last change: 6/25/2005
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU Library General Public License

set -e

[ -z "$MAKEROOTFS_CONFIG" ] && MAKEROOTFS_CONFIG=$PWD/makerootfs.conf
[ ! -e $MAKEROOTFS_CONFIG ] && echo "ERROR: Config file ($MAKEROOTFS_CONFIG) not found!" && exit
. $MAKEROOTFS_CONFIG

! which $TARGET_CC && echo "ERROR: Can't find $TARGET_CC in PATH!" && exit

FILE=acpid_1.0.4-1.tar.gz
BASEURL=http://ftp.debian.org/debian/pool/main/a/acpid/
SRCDIR=acpid-1.0.4

echo === Building $FILE ===

cd $DOWNLOADS
[ ! -e "$FILE" ] && `$WGET $BASEURL$FILE`
cd $BUILDDIR
[ ! -e "$SRCDIR" ] && tar xvzf $DOWNLOADS/$FILE

cd $SRCDIR

sed -i -e "s:ACPI_SOCKETFILE.*:ACPI_SOCKETFILE \"/tmp/acpid.socket\":" acpid.h

mkdir -p $ROOTFS_STAGING/usr/bin
mkdir -p $ROOTFS_STAGING/usr/sbin
mkdir -p $ROOTFS_STAGING/etc/acpi/events

make CC=$TARGET_CC

$TARGET_STRIP -s acpid
$TARGET_STRIP -s acpi_listen

make INSTPREFIX=$ROOTFS_STAGING install

[ ! -e $BUILDDIR/$SRCDIR/.patch_applied ] && patch -p0 --directory $ROOTFS_STAGING < $PATCHES/acpid-scripts.patch
touch $BUILDDIR/$SRCDIR/.patch_applied

chmod 0755 $ROOTFS_STAGING/etc/acpi/default.sh
chmod 0755 $ROOTFS_STAGING/etc/init.d/acpid

cd ..


