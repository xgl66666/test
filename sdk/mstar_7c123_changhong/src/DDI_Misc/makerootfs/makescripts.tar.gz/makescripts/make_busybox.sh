#!/bin/sh
#
# Author: Matthias Ihmig <m.ihmig@mytum.de>
# Last change: 8/11/2005
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU Library General Public License

set -e

[ -z "$MAKEROOTFS_CONFIG" ] && MAKEROOTFS_CONFIG=$PWD/makerootfs.conf
[ ! -e $MAKEROOTFS_CONFIG ] && echo "ERROR: Config file ($MAKEROOTFS_CONFIG) not found!" && exit
. $MAKEROOTFS_CONFIG

! which $TARGET_CC && echo "ERROR: Can't find $TARGET_CC in PATH!" && exit

FILE=busybox-snapshot.tar.bz2
BASEURL=http://www.busybox.net/downloads/snapshots/
SRCDIR=busybox


### Put a # in the following lines if you want to use a snapshot instead (be careful! may not compile!)
cd $DOWNLOADS
[ ! -e "$FILE" ] && `$WGET http://makerootfs.sourceforge.net/mirror/$FILE `
cd ..
###

echo === Building $FILE ===

cd $DOWNLOADS
[ ! -e "$FILE" ] && `$WGET $BASEURL$FILE`
cd $BUILDDIR
[ ! -e "$SRCDIR" ] && tar xvfj $DOWNLOADS/$FILE

cd $SRCDIR
cp $PATCHES/busybox_defconfig .config

yes N | make oldconfig
sed -i -e "s/EXTRA_CFLAGS_OPTIONS=\"\"/EXTRA_CFLAGS_OPTIONS=\"$TARGET_CFLAGS\"/" .config
make dep

make
make PREFIX=$ROOTFS_STAGING install
chmod u+s $ROOTFS_STAGING/bin/busybox

echo "*** removing link /linuxrc -> busybox (only required for initrd)"
rm -f $ROOTFS_STAGING/linuxrc

mkdir -p $ROOTFS_STAGING/etc/init.d/run
mkdir -p $ROOTFS_STAGING/etc/default
mkdir -p $ROOTFS_STAGING/usr/share/udhcpc
mkdir -p $ROOTFS_STAGING/usr/local/bin
install -m 0755 $PATCHES/busybox-udhcpd-initd $ROOTFS_STAGING/etc/init.d/udhcpd
install -m 0755 $PATCHES/busybox-udhcpc-default-script $ROOTFS_STAGING/usr/share/udhcpc/default.script
install -m 0755 $PATCHES/busybox-keymap-initd $ROOTFS_STAGING/etc/init.d/keymap
install -m 0755 $PATCHES/busybox-hwclock-initd $ROOTFS_STAGING/etc/init.d/hwclock
install -m 0755 $PATCHES/busybox-network-initd $ROOTFS_STAGING/etc/init.d/network
install -m 0755 $PATCHES/busybox-syslog-initd $ROOTFS_STAGING/etc/init.d/syslog
install -m 0644 $PATCHES/busybox-syslog.conf $ROOTFS_STAGING/etc/syslog.conf
install -m 0644 $PATCHES/busybox-profile $ROOTFS_STAGING/etc/profile
install -m 0644 $PATCHES/readline-inputrc $ROOTFS_STAGING/etc/inputrc

install -m 0755 $PATCHES/changedns $ROOTFS_STAGING/usr/bin/changedns
install -m 0755 $PATCHES/ldd $ROOTFS_STAGING/usr/bin/ldd
install -m 0755 $PATCHES/busybox-rdate_syncnow $ROOTFS_STAGING/usr/local/bin/rdate_syncnow
install -m 0755 $PATCHES/busybox-setconsoleblankingtime $ROOTFS_STAGING/usr/local/bin/setconsoleblankingtime
install -m 0755 $PATCHES/busybox-ifshowips $ROOTFS_STAGING/usr/local/bin/ifshowips

ln -sf ../keymap $ROOTFS_STAGING/etc/init.d/run/S30keymap
ln -sf ../network $ROOTFS_STAGING/etc/init.d/run/S40network
ln -sf ../syslog $ROOTFS_STAGING/etc/init.d/run/S10syslog

cd ..
