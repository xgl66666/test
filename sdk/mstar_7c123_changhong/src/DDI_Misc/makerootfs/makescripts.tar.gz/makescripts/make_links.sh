#!/bin/sh
#
# Author: Matthias Ihmig <m.ihmig@mytum.de>
# Last change: 6/25/2005
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU Library General Public License

set -e

[ -z "$MAKEROOTFS_CONFIG" ] && MAKEROOTFS_CONFIG=$PWD/makerootfs.conf
[ ! -e $MAKEROOTFS_CONFIG ] && echo "ERROR: Config file ($MAKEROOTFS_CONFIG) not found!" && exit
. $MAKEROOTFS_CONFIG

! which $TARGET_CC && echo "ERROR: Can't find $TARGET_CC in PATH!" && exit

FILE=links-2.1pre17.tar.gz
BASEURL=http://atrey.karlin.mff.cuni.cz/~clock/twibright/links/download/
SRCDIR=links-2.1pre17

echo === Building $FILE ===

cd $DOWNLOADS
[ ! -e "$FILE" ] && `$WGET $BASEURL$FILE`  && echo -n
[ ! -e "$FILE" ] && `$WGET $BASEURLMIRROR$FILE`
cd $BUILDDIR
[ ! -e "$SRCDIR" ] && tar xvzf $DOWNLOADS/$FILE

cd $SRCDIR

CC=$TARGET_CC CFLAGS="$TARGET_CFLAGS -I$ROOTFS_STAGING/usr/include" LDFLAGS="-L$ROOTFS_STAGING/usr/lib" CPPFLAGS="-I$ROOTFS_STAGING/usr/include" ./configure --target=$CROSS_HOST --libdir=$ROOTFS_STAGING/usr/lib \
	--prefix=/usr --sysconfdir=/etc --localstatedir=/tmp \
	--enable-javascript --disable-nls
#	--enable-graphics --with-libjpeg --with-fb

make CC=$TARGET_CC
make DESTDIR=$ROOTFS_STAGING install

#mkdir -p $ROOTFS_STAGING/usr/bin
#install -m 0755 links $ROOTFS_STAGING/usr/bin

cd ..

