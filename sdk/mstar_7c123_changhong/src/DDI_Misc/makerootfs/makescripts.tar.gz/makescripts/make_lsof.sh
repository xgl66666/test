#!/bin/sh
#
# Author: Matthias Ihmig <m.ihmig@mytum.de>
# Last change: 6/25/2005
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU Library General Public License

set -e

[ -z "$MAKEROOTFS_CONFIG" ] && MAKEROOTFS_CONFIG=$PWD/makerootfs.conf
[ ! -e $MAKEROOTFS_CONFIG ] && echo "ERROR: Config file ($MAKEROOTFS_CONFIG) not found!" && exit
. $MAKEROOTFS_CONFIG

! which $TARGET_CC && echo "ERROR: Can't find $TARGET_CC in PATH!" && exit

FILE=lsof_4.75.tar.gz
BASEURL=ftp://lsof.itap.purdue.edu/pub/tools/unix/lsof/
SRCDIR=lsof_4.75

echo === Building $FILE ===

cd $DOWNLOADS
[ ! -e "$FILE" ] && `$WGET $BASEURL$FILE`
cd $BUILDDIR
if [ ! -e "$SRCDIR" ]
then
	tar xvzf $DOWNLOADS/$FILE
	cd $SRCDIR
	tar xfv lsof_4.75_src.tar
fi

cd $BUILDDIR/$SRCDIR/${SRCDIR}_src

CC=$TARGET_CC CFLAGS="$TARGET_CFLAGS" ./Configure -n linux
# --host=$CROSS_HOST --prefix=/usr --disable-nls

make CC=$TARGET_CC CFGL='-L./lib -llsof' DEBUG= INCL="$TARGET_CFLAGS"
# make DESTDIR=$ROOTFS_STAGING install
mkdir -p $ROOTFS_STAGING/usr/sbin/
install -m 4755 lsof $ROOTFS_STAGING/usr/sbin/

cd ..

