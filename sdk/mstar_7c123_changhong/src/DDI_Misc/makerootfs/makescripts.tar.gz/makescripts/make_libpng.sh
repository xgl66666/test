#!/bin/bash
#
# Author: Matthias Ihmig <m.ihmig@mytum.de>
# Last change: 6/25/2005
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU Library General Public License

set -e

[ -z "$MAKEROOTFS_CONFIG" ] && MAKEROOTFS_CONFIG=$PWD/makerootfs.conf
[ ! -e $MAKEROOTFS_CONFIG ] && echo "ERROR: Config file ($MAKEROOTFS_CONFIG) not found!" && exit
. $MAKEROOTFS_CONFIG

! which $TARGET_CC && echo "ERROR: Can't find $TARGET_CC in PATH!" && exit

FILE=libpng-1.2.8.tar.gz
BASEURL=http://download.sourceforge.net/libpng/
SRCDIR=libpng-1.2.8

echo === Building $FILE ===

cd $DOWNLOADS
[ ! -e "$FILE" ] && until `$WGET $BASEURL$FILE`; do sleep 1; done
cd $BUILDDIR
[ ! -e "$SRCDIR" ] && tar xvzf $DOWNLOADS/$FILE

cd $SRCDIR

sed < scripts/makefile.linux > makefile -e 's/^ZLIBINC.*//' -e 's/^ZLIBLIB.*//'
sed -i -e 's/prefix\=\/usr\/local/prefix\=\/usr/' makefile
make ZLIBINC="$MYROOOTFSBIG/usr/include" ZLIBLIB="$ROOTFS_STAGING/usr/lib" CC=$TARGET_CC LD=$TARGET_LD RANLIB="$CROSS_HOST-ranlib"

make install DESTDIR=$ROOTFS_STAGING CC=$TARGET_CC LD=$TARGET_LD RANLIB="$CROSS_HOST-ranlib"

rm $ROOTFS_STAGING/usr/bin/libpng*-config

cd ..
