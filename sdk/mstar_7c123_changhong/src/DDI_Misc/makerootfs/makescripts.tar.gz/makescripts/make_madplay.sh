#!/bin/sh
#
# Author: Matthias Ihmig <m.ihmig@mytum.de>
# Last change: 6/25/2005
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU Library General Public License

set -e

[ -z "$MAKEROOTFS_CONFIG" ] && MAKEROOTFS_CONFIG=$PWD/makerootfs.conf
[ ! -e $MAKEROOTFS_CONFIG ] && echo "ERROR: Config file ($MAKEROOTFS_CONFIG) not found!" && exit
. $MAKEROOTFS_CONFIG

! which $TARGET_CC && echo "ERROR: Can't find $TARGET_CC in PATH!" && exit

FILE=madplay-0.15.2b.tar.gz
BASEURL=ftp://ftp.mars.org/pub/mpeg/
SRCDIR=madplay-0.15.2b

echo === Building $FILE ===

cd $DOWNLOADS
[ ! -e "$FILE" ] && `$WGET $BASEURL$FILE`
cd $BUILDDIR
[ ! -e "$SRCDIR" ] && tar xvzf $DOWNLOADS/$FILE

cd $SRCDIR

CC=$TARGET_CC CXX=$TARGET_CC CFLAGS="$TARGET_CFLAGS" LDFLAGS="-L$ROOTFS_STAGING/usr/lib" CPPFLAGS="-I$ROOTFS_STAGING/usr/include" ./configure \
 	--host=$CROSS_HOST --prefix=/usr \
  	--sysconfdir=/etc --disable-shared --disable-nls

make CC=$TARGET_CC CXX=$TARGET_CC CPPFLAGS="-I$ROOTFS_STAGING/usr/include" LDFLAGS="-L$ROOTFS_STAGING/usr/lib"
make DESTDIR=$ROOTFS_STAGING install

rm -rf $ROOTFS_STAGING/usr/bin/abxtest

cd ..
