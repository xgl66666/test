#!/bin/bash
#
# Author: Matthias Ihmig <m.ihmig@mytum.de>
# Last change: 6/25/2005
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU Library General Public License

set -e

[ -z "$MAKEROOTFS_CONFIG" ] && MAKEROOTFS_CONFIG=$PWD/makerootfs.conf
[ ! -e $MAKEROOTFS_CONFIG ] && echo "ERROR: Config file ($MAKEROOTFS_CONFIG) not found!" && exit
. $MAKEROOTFS_CONFIG

! which $TARGET_CC && echo "ERROR: Can't find $TARGET_CC in PATH!" && exit

if [ ! -d "$KERNEL_PATH" ]
then
	echo "WARNING: Kernel sources not found in $KERNEL_PATH!"
	echo "Some packages need them to compile and may fail otherwise."
	echo -n "Do you still want to continue? [y/N]"
	read ASK
	[ ! $ASK == "y" ] && exit 1
fi

FILE=pcmcia-cs-3.2.8.tar.gz
BASEURL=http://download.sourceforge.net/pcmcia-cs/
SRCDIR=pcmcia-cs-3.2.8

echo === Building $FILE ===

cd $DOWNLOADS
[ ! -e "$FILE" ] && until `$WGET $BASEURL$FILE`; do sleep 1; done
cd $BUILDDIR
[ ! -e "$SRCDIR" ] && tar xvzf $DOWNLOADS/$FILE

cd $SRCDIR

./Configure --noprompt --kernel="$KERNEL_PATH" --target="$ROOTFS_STAGING" --moddir="$ROOTFS_STAGING/lib/modules/$KVER" --arch=$ARCH --ucc=$TARGET_CC --kcc=$TARGET_CC --ld=$TARGET_LD --kflags=-Os --uflags=-Os --trust --nocardbus --nopnp --nox11 --srctree --sysv --rcdir=/etc

sed -i -e "s/pump/udhcpc/" etc/network

[ ! -e $BUILDDIR/$SRCDIR/.patch_applied ] && patch -N -p1 < $PATCHES/pcmcia-base.patch
[ ! -e $BUILDDIR/$SRCDIR/.patch_applied ] && patch -N -p1 < $PATCHES/pcmcia-ds-renamed-to-pcmcia.patch
touch $BUILDDIR/$SRCDIR/.patch_applied

make all

make install

chmod u+w $ROOTFS_STAGING/etc/init.d/pcmcia
chmod u+w $ROOTFS_STAGING/etc/pcmcia/*

rm -rf $ROOTFS_STAGING/etc/rc?.d
rm -rf $ROOTFS_STAGING/etc/rc?.d
rm -f  $ROOTFS_STAGING/etc/modules.conf

mkdir -p $ROOTFS_STAGING/etc/init.d/run
ln -sf ../pcmcia $ROOTFS_STAGING/etc/init.d/run/S50pcmcia

cd ..

