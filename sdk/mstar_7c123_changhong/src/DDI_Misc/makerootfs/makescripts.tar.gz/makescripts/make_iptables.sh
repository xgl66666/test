#!/bin/bash
#
# Author: Matthias Ihmig <m.ihmig@mytum.de>
# Last change: 6/25/2005
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU Library General Public License

set -e

[ -z "$MAKEROOTFS_CONFIG" ] && MAKEROOTFS_CONFIG=$PWD/makerootfs.conf
[ ! -e $MAKEROOTFS_CONFIG ] && echo "ERROR: Config file ($MAKEROOTFS_CONFIG) not found!" && exit
. $MAKEROOTFS_CONFIG

! which $TARGET_CC && echo "ERROR: Can't find $TARGET_CC in PATH!" && exit

FILE=iptables-1.3.1.tar.bz2
BASEURL=http://www.netfilter.org/files/
SRCDIR=iptables-1.3.1

echo === Building $FILE ===

cd $DOWNLOADS
[ ! -e "$FILE" ] && `$WGET $BASEURL$FILE`
cd $BUILDDIR
[ ! -e "$SRCDIR" ] && tar xvjf $DOWNLOADS/$FILE

cd $SRCDIR

sed -i -e "s/# NO_SHARED_LIBS = 1/NO_SHARED_LIBS = 1/" Makefile
sed -i -e "s/# DO_IPV6 = 0/DO_IPV6 = 0/" Makefile

CC=$TARGET_CC LD=$TARGET_LD AR=$CROSS_HOST-ar CFLAGS="$TARGET_CFLAGS" \
make DO_MULTI=1 BINDIR=/usr/bin LIBDIR=/usr/lib KERNEL_DIR=$KERNEL_PATH

CC=$TARGET_CC LD=$TARGET_LD AR=$CROSS_HOST-ar CFLAGS="$TARGET_CFLAGS" \
make install DO_MULTI=1 BINDIR=$ROOTFS_STAGING/usr/bin LIBDIR=$ROOTFS_STAGING/usr/lib \
	MANDIR=$ROOTFS_STAGING/usr/man install

rm $ROOTFS_STAGING/usr/bin/ip6tables

mkdir -p $ROOTFS_STAGING/usr/local/bin
install -m 0755 $PATCHES/iptables-nat_example $ROOTFS_STAGING/usr/local/bin

cd ..
