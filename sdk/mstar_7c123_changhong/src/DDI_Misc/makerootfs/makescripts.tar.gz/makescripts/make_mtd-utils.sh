#!/bin/sh
#
# Author: Matthias Ihmig <m.ihmig@mytum.de>
# Last change: 6/25/2005
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU Library General Public License

set -e

HOST_UTILS="mkfs.jffs2"
ARM_UTILS="flash_erase flash_eraseall flash_info flash_lock flash_unlock flashcp ftl_format ftl_check mtd_debug"

[ -z "$MAKEROOTFS_CONFIG" ] && MAKEROOTFS_CONFIG=$PWD/makerootfs.conf
[ ! -e $MAKEROOTFS_CONFIG ] && echo "ERROR: Config file ($MAKEROOTFS_CONFIG) not found!" && exit
. $MAKEROOTFS_CONFIG

! which $TARGET_CC && echo "ERROR: Can't find $TARGET_CC in PATH!" && exit

FILE=mtd-snapshot-20050622.tar.bz2
#FILE=mtd-snapshot-20050205.tar.bz2
#FILE=mtd-snapshot-20040826.tar.bz2
BASEURL=http://svn.rungie.com/files/
SRCDIR=mtd

echo === Building $FILE ===

cd $DOWNLOADS
[ ! -e "$FILE" ] && `$WGET $BASEURL$FILE`
cd $BUILDDIR
[ ! -e "$SRCDIR" ] && tar xvjf $DOWNLOADS/$FILE

cd $SRCDIR

! cp $ROOTFS_STAGING/usr/include/zlib.h include/zlib.h && echo "*** Warning: zlib.h not found. If build fails, install zlib on your system"
# patch -N -p1 < $PATCHES/mtd-osx.patch && echo

cd util

mkdir -p $ROOTFS_STAGING/usr/bin
echo "*** building mtd arm utilities"
for prg in ${ARM_UTILS}
do
	make CROSS="$CROSS_HOST-" LINUXDIR=$KERNEL_PATH ${prg}
	install -m 0755 ${prg} $ROOTFS_STAGING/usr/bin/
done

echo "*** building mtd host utilities"

make clean

# build mtd host utilities
for prg in ${HOST_UTILS}
do
	make LINUXDIR=$KERNEL_PATH ${prg}
	install -m 0755 ${prg} $BUILDDIR
done

make clean

mkdir -p $ROOTFS_STAGING/usr/local/bin
install -m 0755 $PATCHES/mtd-flashupdate $ROOTFS_STAGING/usr/local/bin/flashupdate

cd ..

