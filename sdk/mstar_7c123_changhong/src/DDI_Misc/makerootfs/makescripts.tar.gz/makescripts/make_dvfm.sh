#!/bin/sh
#
# Author: Matthias Ihmig <m.ihmig@mytum.de>
# Last change: 6/25/2005
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU Library General Public License

set -e

[ -z "$MAKEROOTFS_CONFIG" ] && MAKEROOTFS_CONFIG=$PWD/makerootfs.conf
[ ! -e $MAKEROOTFS_CONFIG ] && echo "ERROR: Config file ($MAKEROOTFS_CONFIG) not found!" && exit
. $MAKEROOTFS_CONFIG

! which $TARGET_CC && echo "ERROR: Can't find $TARGET_CC in PATH!" && exit

FILE=dvfm.tar.gz
BASEURL=ftp://ftp.linux.org.uk/pub/linux/arm/people/xscale/mainstone/01-27-2005/src/rootfs/
SRCDIR=dvfm

echo === Building $FILE ===

cd $DOWNLOADS
[ ! -e "$FILE" ] && `$WGET $BASEURL$FILE`
cd $BUILDDIR
[ ! -e "$SRCDIR" ] && tar xvzf $DOWNLOADS/$FILE

cd $SRCDIR

cp $PATCHES/dvfm-ipmc.h ipmc.h

make clean
make
mkdir -p $ROOTFS_STAGING/usr/bin
install -m 0755 dvfm $ROOTFS_STAGING/usr/bin/

mkdir -p $ROOTFS_STAGING/usr/local/bin
install -m 0755 $PATCHES/dvfm-example-285mhz $ROOTFS_STAGING/usr/local/bin/dvfm-285mhz

cd ..
