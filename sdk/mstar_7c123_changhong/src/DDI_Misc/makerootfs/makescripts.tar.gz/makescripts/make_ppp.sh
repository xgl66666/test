#!/bin/sh
#
# Author: Matthias Ihmig <m.ihmig@mytum.de>
# Last change: 6/25/2005
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU Library General Public License

set -e

[ -z "$MAKEROOTFS_CONFIG" ] && MAKEROOTFS_CONFIG=$PWD/makerootfs.conf
[ ! -e $MAKEROOTFS_CONFIG ] && echo "ERROR: Config file ($MAKEROOTFS_CONFIG) not found!" && exit
. $MAKEROOTFS_CONFIG

! which $TARGET_CC && echo "ERROR: Can't find $TARGET_CC in PATH!" && exit

FILE=ppp-2.4.1.tar.gz
BASEURL=ftp://ftp.samba.org/pub/ppp/
SRCDIR=ppp-2.4.1

echo === Building $FILE ===

cd $DOWNLOADS
[ ! -e "$FILE" ] && `$WGET $BASEURL$FILE`
cd $BUILDDIR
[ ! -e "$SRCDIR" ] && tar xvzf $DOWNLOADS/$FILE

cd $SRCDIR

sed -i -e 's/ -DIPX_CHANGE -DHAVE_MULTILINK -DHAVE_MMAP//' pppd/Makefile.linux
sed -i -e 's/$(INSTALL) -s/$(INSTALL)/' */Makefile.linux
sed -i -e 's/ -o root//' */Makefile.linux
sed -i -e 's/ -g daemon//' */Makefile.linux

CC=$TARGET_CC CFLAGS="$TARGET_CFLAGS" ./configure --host=$CROSS_HOST --prefix=/usr \
	--sysconfdir=/etc --localstatedir=/var --disable-nls

make CC=$TARGET_CC
make DESTDIR=$ROOTFS_STAGING CC=$TARGET_CC install

rm $ROOTFS_STAGING/etc/ppp/options
[ ! -e $BUILDDIR/$SRCDIR/.patch_applied ] && patch -N -p1 --directory=$ROOTFS_STAGING/etc/ppp < $PATCHES/ppp-base.patch
touch $BUILDDIR/$SRCDIR/.patch_applied

mkdir -p $ROOTFS_STAGING/etc/init.d
install -m 0755 $PATCHES/ppp-initd $ROOTFS_STAGING/etc/init.d/ppp

install -m 0755 $PATCHES/ppp-poff $ROOTFS_STAGING/usr/bin/poff
install -m 0755 $PATCHES/ppp-pon  $ROOTFS_STAGING/usr/bin/pon

cd ..

