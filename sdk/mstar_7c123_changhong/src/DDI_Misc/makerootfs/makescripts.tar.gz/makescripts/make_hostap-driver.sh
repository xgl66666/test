#!/bin/sh
#
# Author: Matthias Ihmig <m.ihmig@mytum.de>
# Last change: 6/25/2005
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU Library General Public License

set -e

[ -z "$MAKEROOTFS_CONFIG" ] && MAKEROOTFS_CONFIG=$PWD/makerootfs.conf
[ ! -e $MAKEROOTFS_CONFIG ] && echo "ERROR: Config file ($MAKEROOTFS_CONFIG) not found!" && exit
. $MAKEROOTFS_CONFIG

! which $TARGET_CC && echo "ERROR: Can't find $TARGET_CC in PATH!" && exit

[ ! -e "$KERNEL_PATH/include/linux/version.h" ] && echo "ERROR: Kernel missing or not compiled in $KERNEL_PATH!" && exit 1

FILE=hostap-driver-0.3.9.tar.gz
BASEURL=http://hostap.epitest.fi/releases/
SRCDIR=hostap-driver-0.3.9
echo === Building $FILE ===

mkdir -p $ROOTFS_STAGING/lib/modules/$KVERS

cd $DOWNLOADS
[ ! -e "$FILE" ] && `$WGET $BASEURL$FILE`
cd $BUILDDIR
[ ! -e "$SRCDIR" ] && tar xvzf $DOWNLOADS/$FILE

cd $SRCDIR

[ ! -e $BUILDDIR/$SRCDIR/.patch_applied ] && patch -N -p1 < $PATCHES/hostap-driver-main-makefile.patch
[ ! -e $BUILDDIR/$SRCDIR/.patch_applied ] && patch -N -p0 < $PATCHES/hostap-driver-conf.patch
touch $BUILDDIR/$SRCDIR/.patch_applied

CROSS_COMPILE="$CROSS_HOST-" ARCH="$ARCH" make DESTDIR=$ROOTFS_STAGING CC=$TARGET_CC
CROSS_COMPILE="$CROSS_HOST-" ARCH="$ARCH" make DESTDIR=$ROOTFS_STAGING install

cd $ROOTFS_STAGING
#cat $PATCHES/hostap-driver-hostap_cs-sychip.conf >> $ROOTFS_STAGING/etc/pcmcia/hostap_cs.conf
[ ! -e $BUILDDIR/$SRCDIR/.patch2_applied ] && patch -p0 < $PATCHES/hostap-driver-hostap_cs-sychip.patch
[ ! -e $BUILDDIR/$SRCDIR/.patch2_applied ] && patch -p0 < $PATCHES/hostap-hotplug.patch
touch $BUILDDIR/$SRCDIR/.patch2_applied

rm $ROOTFS_STAGING/lib/modules/$KVERS/kernel/drivers/net/wireless/hostap_plx.ko
rm $ROOTFS_STAGING/lib/modules/$KVERS/kernel/drivers/net/wireless/hostap_pci.ko

$TARGET_STRIP --strip-unneeded -x -X $ROOTFS_STAGING/lib/modules/$KVERS/kernel/drivers/net/wireless/*

cd ..

