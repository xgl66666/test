#!/bin/sh
#
# Author: Matthias Ihmig <m.ihmig@mytum.de>
# Last change: 6/25/2005
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU Library General Public License

set -e

[ -z "$MAKEROOTFS_CONFIG" ] && MAKEROOTFS_CONFIG=$PWD/makerootfs.conf
[ ! -e $MAKEROOTFS_CONFIG ] && echo "ERROR: Config file ($MAKEROOTFS_CONFIG) not found!" && exit
. $MAKEROOTFS_CONFIG

! which $TARGET_CC && echo "ERROR: Can't find $TARGET_CC in PATH!" && exit

FILE=openssl-0.9.7d.tar.gz
BASEURL=http://www.openssl.org/source/
SRCDIR=openssl-0.9.7d
# soft float may be needed for gcc-version != 3.4
#TARGET_SOFT_FLOAT=-msoft-float

echo === Building $FILE ===

cd $DOWNLOADS
[ ! -e "$FILE" ] && `$WGET $BASEURL$FILE`
cd $BUILDDIR
[ ! -e "$SRCDIR" ] && tar xvzf $DOWNLOADS/$FILE

cd $SRCDIR

[ ! -e $BUILDDIR/$SRCDIR/.patch_applied ] && patch -N -p1 < $PATCHES/openssl.patch
touch $BUILDDIR/$SRCDIR/.patch_applied

sed -i -e "s,/CFLAG=,/CFLAG= $TARGET_SOFT_FLOAT ,g" Configure

CFLAGS="$TARGET_CFLAGS -DOPENSSL_NO_KRB5 -DOPENSSL_NO_IDEA -DOPENSSL_NO_MDC2 -DOPENSSL_NO_RC5" \
PATH=$BUILDDIR:$BUILDDIR/bin:$PATH ./Configure linux-$ARCH --prefix=/usr \
	--openssldir=/usr/lib/ssl -L$ROOTFS_STAGING/usr/lib -ldl -I$ROOTFS_STAGING/usr/include $OPENSSL_OPTS \
	no-threads shared no-idea no-mdc2 no-rc5

make CC=$TARGET_CC all build-shared
# Work around openssl build bug to link libssl.so with libcrypto.so.
rm libssl.so.*.*.*
make CC=$TARGET_CC do_linux-shared

make CC=$TARGET_CC INSTALL_PREFIX=$ROOTFS_STAGING install

cd ..
