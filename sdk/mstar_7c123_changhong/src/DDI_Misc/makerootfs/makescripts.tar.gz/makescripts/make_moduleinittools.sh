#!/bin/sh
#
# Author: Matthias Ihmig <m.ihmig@mytum.de>
# Last change: 6/25/2005
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU Library General Public License

set -e

[ -z "$MAKEROOTFS_CONFIG" ] && MAKEROOTFS_CONFIG=$PWD/makerootfs.conf
[ ! -e $MAKEROOTFS_CONFIG ] && echo "ERROR: Config file ($MAKEROOTFS_CONFIG) not found!" && exit
. $MAKEROOTFS_CONFIG

! which $TARGET_CC && echo "ERROR: Can't find $TARGET_CC in PATH!" && exit

FILE=module-init-tools-3.1.tar.gz
BASEURL=http://ftp.kernel.org/pub/linux/kernel/people/rusty/modules/
SRCDIR=module-init-tools-3.1

echo === Building $FILE ===

cd $DOWNLOADS
[ ! -e "$FILE" ] && `$WGET $BASEURL$FILE`
cd $BUILDDIR
[ ! -e "$SRCDIR" ] && tar xvzf $DOWNLOADS/$FILE

cd $SRCDIR

./configure --prefix=$ROOTFS_STAGING --host=$CROSS_HOST
make && make install

mkdir -p $ROOTFS_STAGING/etc
install -m 0644 $PATCHES/modprobe.conf $ROOTFS_STAGING/etc/

echo "*** Removing /sbin/insmod.static (pretty big; if you need it, copy it manually from build directory)"
rm -f $ROOTFS_STAGING/sbin/insmod.static

echo
echo " *** If you used modutils with a 2.4 kernel tools before,"
echo " *** run natively on ARM machine to import old settings:"
echo " *** ./generate-modprobe.conf /etc/modprobe.conf"
echo " *** to generate modprobe.conf from modules.conf"
echo " *** If devfs is used, copy modprobe.devfs to /etc"

cd ..
