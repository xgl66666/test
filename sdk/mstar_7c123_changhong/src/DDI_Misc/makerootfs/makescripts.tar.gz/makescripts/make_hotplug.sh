#!/bin/bash
#
# Author: Matthias Ihmig <m.ihmig@mytum.de>
# Last change: 6/25/2005
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU Library General Public License

set -e

[ -z "$MAKEROOTFS_CONFIG" ] && MAKEROOTFS_CONFIG=$PWD/makerootfs.conf
[ ! -e $MAKEROOTFS_CONFIG ] && echo "ERROR: Config file ($MAKEROOTFS_CONFIG) not found!" && exit
. $MAKEROOTFS_CONFIG

! which $TARGET_CC && echo "ERROR: Can't find $TARGET_CC in PATH!" && exit

FILE=hotplug-2004_03_29.tar.gz
BASEURL=http://download.sourceforge.net/linux-hotplug/
SRCDIR=hotplug-2004_03_29

echo === Building $FILE ===

cd $DOWNLOADS
[ ! -e "$FILE" ] && until `$WGET $BASEURL$FILE`; do sleep 1; done
cd $BUILDDIR
[ ! -e "$SRCDIR" ] && tar xvzf $DOWNLOADS/$FILE

cd $SRCDIR

make prefix=$ROOTFS_STAGING install

cd $ROOTFS_STAGING
rm -f etc/hotplug/isapnp.rc etc/hotplug/mmc.agent etc/hotplug/sleeve.agent etc/hotplug/sleeve.rc
rm -f etc/hotplug/usbd.agent etc/sysconfig/hotplug usr/sbin/update-usb.usermap
[ ! -e $BUILDDIR/$SRCDIR/.patch_applied ] && patch -N -p0 < $PATCHES/hotplug-base.patch
touch $BUILDDIR/$SRCDIR/.patch_applied
chmod ugo+x etc/hotplug/usb/* etc/hotplug/*.agent etc/hotplug/*.rc

rm -rf var/

cd ..

