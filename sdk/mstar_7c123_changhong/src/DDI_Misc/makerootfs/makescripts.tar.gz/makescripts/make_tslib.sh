#!/bin/sh
#
# Author: Matthias Ihmig <m.ihmig@mytum.de>
# Last change: 8/11/2005
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU Library General Public License

set -e
echo === Building test ===
echo "include var_list"
VAR_LIST=../../../bsp/linux/partition/auto_gen_output/var_list
[ ! -e ${VAR_LIST} ] && echo "ERROR: Config file ${VAR_LIST} not found!" && exit 1
source ${VAR_LIST}
MAKEROOTFS_CONFIG=../../../../../../DDI_Misc/makerootfs/makerootfs.conf
#[ -z "$MAKEROOTFS_CONFIG" ] && MAKEROOTFS_CONFIG=$PWD/makerootfs.conf
[ ! -e $MAKEROOTFS_CONFIG ] && echo "ERROR: Config file ($MAKEROOTFS_CONFIG) not found!" && exit
. $MAKEROOTFS_CONFIG
echo $TARGET_CC
! which $TARGET_CC && echo "ERROR: Can't find $TARGET_CC in PATH!" && exit

FILE=tslib-cvs.tar.gz
SRCDIR=tslib


### Put a # in the following line if you want to use a CVS snapshot instead (be careful! may not compile!)
cd $DOWNLOADS
[ ! -e "$FILE" ] && `$WGET http://makerootfs.sourceforge.net/mirror/$FILE`
cd ..
###


echo === Building $FILE ===
echo $BUILDDIR
cd $BUILDDIR
rm -rf $SRCDIR
if [ ! -e "$SRCDIR" ]
then
	# echo "*** No CVS password, so just press Enter if asked"
	[ ! -e "$DOWNLOADS/$FILE" ]  && cvs -d:pserver:cvs:@pubcvs.arm.linux.org.uk/mnt/src/cvsroot login \
		&& cvs -d:pserver:cvs@pubcvs.arm.linux.org.uk/mnt/src/cvsroot co tslib \
		&& touch .checked_out_`date +%Y-%m-%d_%H%M` \
		&& tar cfvz $DOWNLOADS/$FILE tslib/ .checked_out*

	[ -e "$DOWNLOADS/$FILE" ] && tar xvzf $DOWNLOADS/$FILE
fi

cd $SRCDIR
./autogen.sh
CFLAGS="$TARGET_CFLAGS" ./configure --prefix=$ROOTFS_STAGING/usr --sysconfdir=$ROOTFS_STAGING/etc --host=$CROSS_HOST --disable-linear-h2200 --disable-h3600 --disable-mk712 --disable-arctic2 --disable-corgi --disable-collie --enable-static --enable-shared

  # bugfix
[ ! -e $BUILDDIR/$SRCDIR/.patch_applied ] && patch -N -p1 < $PATCHES/tslib-typecast.patch
  # edit config.h and put "define rpl_malloc" into comments  or apply patch
[ ! -e $BUILDDIR/$SRCDIR/.patch_applied ] && patch -N -p1 < $PATCHES/tslib-rpl_malloc.patch

[ ! -e $BUILDDIR/$SRCDIR/.patch_applied ] && patch -N -p1 < $PATCHES/tslib-tsconf.patch

touch $BUILDDIR/$SRCDIR/.patch_applied

make
make install
cd ..
