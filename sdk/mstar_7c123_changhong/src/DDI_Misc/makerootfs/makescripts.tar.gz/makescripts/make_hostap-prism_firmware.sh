#!/bin/sh
#
# Author: Matthias Ihmig <m.ihmig@mytum.de>
# Last change: 6/25/2005
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU Library General Public License

set -e

[ -z "$MAKEROOTFS_CONFIG" ] && MAKEROOTFS_CONFIG=$PWD/makerootfs.conf
[ ! -e $MAKEROOTFS_CONFIG ] && echo "ERROR: Config file ($MAKEROOTFS_CONFIG) not found!" && exit
. $MAKEROOTFS_CONFIG

FWBASEURL=http://www.netgate.com/support/prism_firmware/
FWFILEPRI=primary.tar.gz
FWFILESTAVER=1.8.3
FWFILESTA=$FWFILESTAVER.tar.gz
FWFILEPM=pm010102.hex
FWFILERF=rf010803.hex

mkdir -p $ROOTFS_STAGING/etc/pcmcia/prism_fw/

cd $DOWNLOADS
[ ! -e "$FWFILEPRI" ] && `$WGET $FWBASEURL$FWFILEPRI`
[ ! -e "$FWFILESTA" ] && `$WGET $FWBASEURL$FWFILESTA`

cd $BUILDDIR
[ ! -e "primary" ] && tar xvzf $DOWNLOADS/$FWFILEPRI
[ ! -e "$FWFILESTAVER" ] && tar xvzf $DOWNLOADS/$FWFILESTA

install -m 0644 $BUILDDIR/primary/$FWFILEPM $ROOTFS_STAGING/etc/pcmcia/prism_fw/
install -m 0644 $BUILDDIR/$FWFILESTAVER/$FWFILERF $ROOTFS_STAGING/etc/pcmcia/prism_fw/
rm $ROOTFS_STAGING/etc/pcmcia/prism_fw/prism2_pm.hex $ROOTFS_STAGING/etc/pcmcia/prism_fw/prism2_rf.hex && echo
ln -sf $FWFILEPM $ROOTFS_STAGING/etc/pcmcia/prism_fw/prism2_pm.hex
ln -sf $FWFILERF $ROOTFS_STAGING/etc/pcmcia/prism_fw/prism2_rf.hex

cd $ROOTFS_STAGING
[ ! -e $BUILDDIR/$SRCDIR/.patch_applied ] && patch -N -p0 < $PATCHES/hostap-prism-network-loadfw.patch
touch $BUILDDIR/$SRCDIR/.patch_applied

cd ..
