#!/bin/sh
#
# Author: Matthias Ihmig <m.ihmig@mytum.de>
# Last change: 6/25/2005
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU Library General Public License

set -e

[ -z "$MAKEROOTFS_CONFIG" ] && MAKEROOTFS_CONFIG=$PWD/makerootfs.conf
[ ! -e $MAKEROOTFS_CONFIG ] && echo "ERROR: Config file ($MAKEROOTFS_CONFIG) not found!" && exit
. $MAKEROOTFS_CONFIG

! which $TARGET_CC && echo "ERROR: Can't find $TARGET_CC in PATH!" && exit

FILE=hostap.tar.gz
URL=http://hostap.epitest.fi/cgi-bin/viewcvs.cgi/hostap/hostap.tar.gz?tarball=1
SRCDIR=hostap

echo === Building $FILE ===

mkdir -p $ROOTFS_STAGING/lib/modules/$KVERS

mkdir -p $ROOTFS_STAGING/usr/sbin

mkdir -p $ROOTFS_STAGING/etc/pcmcia/prism_fw/
touch $ROOTFS_STAGING/etc/pcmcia/prism_fw/prism2_pm.hex
touch $ROOTFS_STAGING/etc/pcmcia/prism_fw/prism2_rf.hex


cd $DOWNLOADS
[ ! -e "$FILE" ] && `$WGET $URL` && mv "hostap.tar.gz?tarball=1" $FILE

cd $BUILDDIR
[ ! -e "$SRCDIR" ] && tar xvzf $DOWNLOADS/$FILE

cd $SRCDIR

#################################
echo "*** Building hostap drivers"

[ ! -e $BUILDDIR/$SRCDIR/.patch_applied ] && patch -N -p1 < $PATCHES/hostap-driver-main-makefile.patch
[ ! -e $BUILDDIR/$SRCDIR/.patch_applied ] && patch -N -p0 < $PATCHES/hostap-driver-conf.patch
touch $BUILDDIR/$SRCDIR/.patch_applied

sed -i -e "s,/.*#define PRISM2_DOWNLOAD_SUPPORT.*/,#define PRISM2_DOWNLOAD_SUPPORT,g" driver/modules/hostap_config.h

make DESTDIR=$ROOTFS_STAGING KERNEL_PATH=$KERNEL_PATH CROSS_COMPILE="$CROSS_HOST-" CC=$TARGET_CC CFLAGS="$TARGET_CFLAGS -Wall -MMD" 2.6

make DESTDIR=$ROOTFS_STAGING KERNEL_PATH=$KERNEL_PATH CROSS_COMPILE="$CROSS_HOST-" CC=$TARGET_CC CFLAGS="$TARGET_CFLAGS -Wall -MMD install_2.6"

mkdir -p $ROOTFS_STAGING/etc/pcmcia
cp -Rf driver/etc/hostap_cs.conf $ROOTFS_STAGING/etc/pcmcia

#cat $PATCHES/hostap-driver-hostap_cs-sychip.conf >> $ROOTFS_STAGING/etc/pcmcia/hostap_cs.conf
cd $ROOTFS_STAGING
[ ! -e $BUILDDIR/$SRCDIR/.patch2_applied ] && patch -p0 < $PATCHES/hostap-driver-hostap_cs-sychip.patch
[ ! -e $BUILDDIR/$SRCDIR/.patch2_applied ] && patch -p0 < $PATCHES/hostap-hotplug.patch
touch $BUILDDIR/$SRCDIR/.patch2_applied

rm $ROOTFS_STAGING/lib/modules/$KVERS/kernel/drivers/net/wireless/hostap_plx.ko
rm $ROOTFS_STAGING/lib/modules/$KVERS/kernel/drivers/net/wireless/hostap_pci.ko

$TARGET_STRIP --strip-unneeded -x -X $ROOTFS_STAGING/lib/modules/$KVERS/kernel/drivers/net/wireless/*

#################################
echo "*** Building hostap utils"

cd utils

CC=$TARGET_CC LD=$TARGET_LD CFLAGS="$TARGET_CFLAGS" make DESTDIR=$ROOTFS_STAGING KERNEL_PATH=$KERNEL_PATH CROSS_COMPILE="$CROSS_HOST-" CC=$TARGET_CC CFLAGS="-Wall $TARGET_CFLAGS -I../driver/modules"

sed -i -e "s/PRI=\/etc\/pcmcia\/PM010102.HEX/PRI=\/etc\/pcmcia\/prism_fw\/prism2_pm.hex/" hostap_fw_load
sed -i -e "s/STA=\/etc\/pcmcia\/RF010802.HEX/PRI=\/etc\/pcmcia\/prism_fw\/prism2_rf.hex/" hostap_fw_load
sed -i -e "s/PRISM2_SREC=\/usr\/local\/bin\/prism2_srec/PRISM2_SREC=\/usr\/sbin\/prism2_srec/" hostap_fw_load

install -m 0755 hostap_crypt_conf  hostap_diag  hostap_fw_load  hostap_io_debug  hostap_rid  prism2_param  prism2_srec  split_combined_hex $ROOTFS_STAGING/usr/sbin

cd ..

#################################
echo "*** Building hostap daemon"

cd hostapd

cp -f $PATCHES/hostapd.config .config

make DESTDIR=$ROOTFS_STAGING KERNEL_PATH=$KERNEL_PATH CROSS_COMPILE="$CROSS_HOST-" CC=$TARGET_CC CFLAGS="-Wall $TARGET_CFLAGS -I../driver/modules -I../utils -I../wpa_supplicant"

install -m 0755 hostapd $ROOTFS_STAGING/usr/sbin

cd ..
