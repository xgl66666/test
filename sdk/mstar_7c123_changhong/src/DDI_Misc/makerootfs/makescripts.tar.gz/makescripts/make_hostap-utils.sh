#!/bin/sh
#
# Author: Matthias Ihmig <m.ihmig@mytum.de>
# Last change: 6/25/2005
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU Library General Public License

set -e

[ -z "$MAKEROOTFS_CONFIG" ] && MAKEROOTFS_CONFIG=$PWD/makerootfs.conf
[ ! -e $MAKEROOTFS_CONFIG ] && echo "ERROR: Config file ($MAKEROOTFS_CONFIG) not found!" && exit
. $MAKEROOTFS_CONFIG

! which $TARGET_CC && echo "ERROR: Can't find $TARGET_CC in PATH!" && exit

FILE=hostap-utils-0.3.7.tar.gz
BASEURL=http://hostap.epitest.fi/releases/
SRCDIR=hostap-utils-0.3.7

echo === Building $FILE ===

cd $DOWNLOADS
[ ! -e "$FILE" ] && `$WGET $BASEURL$FILE`

cd $BUILDDIR
[ ! -e "$SRCDIR" ] && tar xvzf $DOWNLOADS/$FILE

cd $SRCDIR

mkdir -p $ROOTFS_STAGING/usr/sbin
mkdir -p $ROOTFS_STAGING/etc/pcmcia/prism_fw/
touch $ROOTFS_STAGING/etc/pcmcia/prism_fw/prism2_pm.hex
touch $ROOTFS_STAGING/etc/pcmcia/prism_fw/prism2_rf.hex

CC=$TARGET_CC LD=$TARGET_LD CFLAGS="$TARGET_CFLAGS" make

sed -i -e "s/PRI=\/etc\/pcmcia\/PM010102.HEX/PRI=\/etc\/pcmcia\/prism_fw\/prism2_pm.hex/" hostap_fw_load
sed -i -e "s/STA=\/etc\/pcmcia\/RF010802.HEX/PRI=\/etc\/pcmcia\/prism_fw\/prism2_rf.hex/" hostap_fw_load
sed -i -e "s/PRISM2_SREC=\/usr\/local\/bin\/prism2_srec/PRISM2_SREC=\/usr\/sbin\/prism2_srec/" hostap_fw_load

install -m 0755 hostap_crypt_conf  hostap_diag  hostap_fw_load  hostap_io_debug  hostap_rid  prism2_param  prism2_srec  split_combined_hex $ROOTFS_STAGING/usr/sbin

mkdir -p $ROOTFS_STAGING/etc/network
cd $ROOTFS_STAGING/etc/network
mkdir -p if-down.d  if-post-down.d  if-pre-up.d  if-up.d
install -m 0755 $PATCHES/hostap-utils-ifpreup if-pre-up.d/hostap-utils

cd ..
