#!/bin/sh
#
# Author: Matthias Ihmig <m.ihmig@mytum.de>
# Last change: 8/11/2005
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU Library General Public License

set -e

[ -z "$MAKEROOTFS_CONFIG" ] && MAKEROOTFS_CONFIG=$PWD/makerootfs.conf
[ ! -e $MAKEROOTFS_CONFIG ] && echo "ERROR: Config file ($MAKEROOTFS_CONFIG) not found!" && exit
. $MAKEROOTFS_CONFIG

! which $TARGET_CC && echo "ERROR: Can't find $TARGET_CC in PATH!" && exit

FILE=alsa-cvs.tar.gz
SRCDIR=alsacvs


### Put a # in the following line if you want to use a CVS snapshot instead (be careful! may not compile!)
cd $DOWNLOADS
[ ! -e "$FILE" ] && `$WGET http://makerootfs.sourceforge.net/mirror/$FILE`
cd ..
###

echo === Building $SRCDIR ===

cd $BUILDDIR

if [ ! -d $SRCDIR ]
then
	mkdir $SRCDIR
	cd $SRCDIR

	if [ ! -e $DOWNLOADS/$FILE ]
	then
		# CVS password is empty
		cvs -d:pserver:anonymous:@cvs.alsa-project.org:/cvsroot/alsa login
		cvs -d:pserver:anonymous@cvs.alsa-project.org:/cvsroot/alsa co -P alsa-driver alsa-kernel alsa-lib alsa-utils \
		&& touch .checked_out_`date +%Y-%m-%d_%H%M` \
		&& tar cfvz $DOWNLOADS/$FILE alsa-driver/ alsa-kernel/ alsa-lib/ alsa-utils/ .checked_out*
	else
		tar xfvz $DOWNLOADS/$FILE
	fi
fi

cd $BUILDDIR/$SRCDIR

# echo "*** build external alsa-driver" --> built through kernel
# cd alsa-driver
# ./cvscompile --with-isapnp=no --with-sequencer=no --with-oss=yes --with-kernel=$KERNEL_PATH \
# 	--with-build=$KERNEL_PATH --with-cards=pxa2xx-ac97 --with-cross="$CROSS_HOST-"\
# 	--prefix=/usr
# make DESTDIR=$ROOTFS_STAGING install
# cd ..

echo "*** build alsa-lib"
cd alsa-lib
./cvscompile --prefix=/usr --sysconfdir=/etc --host=$CROSS_HOST
make DESTDIR=$ROOTFS_STAGING install
cd ..

echo "*** build alsa-utils"
# be ncurses first if you want GUI applications

cp `which gettextize` $BUILDDIR
sed -i -e "s/read dummy/# read dummy/" $BUILDDIR/gettextize

cd alsa-utils
PATH="$BUILDDIR:$PATH" LDFLAGS="-L$ROOTFS_STAGING/usr/lib" CPPFLAGS="-I$ROOTFS_STAGING/usr/include" ./cvscompile \
	--prefix=/usr --sysconfdir=/etc --host=$CROSS_HOST
make DESTDIR=$ROOTFS_STAGING install

cd ..

mkdir -p $ROOTFS_STAGING/etc/init.d
install -m 0755 $PATCHES/alsa-initd $ROOTFS_STAGING/etc/init.d/alsa

cd $ROOTFS_STAGING/usr/bin
rm aconnect amidi aplaymidi arecordmidi aseqdump aseqnet speaker-test
cd $ROOTFS_STAGING/usr/share/alsa
find cards | grep -v -E "^cards$|^cards/aliases|^cards/PC-Speaker.conf" | xargs rm -rf
rm -rf $ROOTFS_STAGING/usr/share/sounds/alsa
