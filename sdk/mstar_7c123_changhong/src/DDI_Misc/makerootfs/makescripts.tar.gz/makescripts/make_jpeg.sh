#!/bin/sh
#
# Author: Matthias Ihmig <m.ihmig@mytum.de>
# Last change: 6/25/2005
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU Library General Public License

set -e

[ -z "$MAKEROOTFS_CONFIG" ] && MAKEROOTFS_CONFIG=$PWD/makerootfs.conf
[ ! -e $MAKEROOTFS_CONFIG ] && echo "ERROR: Config file ($MAKEROOTFS_CONFIG) not found!" && exit
. $MAKEROOTFS_CONFIG

! which $TARGET_CC && echo "ERROR: Can't find $TARGET_CC in PATH!" && exit

FILE=jpegsrc.v6b.tar.gz
BASEURL=ftp://ftp.uu.net/graphics/jpeg/
SRCDIR=jpeg-6b

echo === Building $FILE ===

mkdir -p $ROOTFS_STAGING/usr/include
mkdir -p $ROOTFS_STAGING/usr/lib
mkdir -p $ROOTFS_STAGING/usr/bin
mkdir -p $ROOTFS_STAGING/usr/man/man1

cd $DOWNLOADS
[ ! -e "$FILE" ] && `$WGET $BASEURL$FILE`
cd $BUILDDIR
[ ! -e "$SRCDIR" ] && tar xvzf $DOWNLOADS/$FILE

[ ! -e $BUILDDIR/$SRCDIR/.patch_applied ] && patch -N -p0 < $PATCHES/libjpeg-arm-linux.patch
touch $BUILDDIR/$SRCDIR/.patch_applied

cd $SRCDIR

CC=$TARGET_CC CFLAGS="$TARGET_CFLAGS" ./configure --prefix=/usr --host=$CROSS_HOST --build=i386-linux --enable-shared --enable-static

make all
echo "*** Note: Will install only library and headers (no jpeg tools). Edit $0 to change that!" && sleep 5s

make prefix=$ROOTFS_STAGING/usr exec_prefix=$ROOTFS_STAGING/usr install-headers install-lib

# Uncomment the following line to install everything (incl. tools)
# make prefix=$ROOTFS_STAGING/usr exec_prefix=$ROOTFS_STAGING/usr install

cd ..
