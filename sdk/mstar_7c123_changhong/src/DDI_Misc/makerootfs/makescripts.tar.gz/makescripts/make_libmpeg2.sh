#!/bin/bash
#
# Author: Matthias Ihmig <m.ihmig@mytum.de>
# Last change: 6/25/2005
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU Library General Public License

set -e

[ -z "$MAKEROOTFS_CONFIG" ] && MAKEROOTFS_CONFIG=$PWD/makerootfs.conf
[ ! -e $MAKEROOTFS_CONFIG ] && echo "ERROR: Config file ($MAKEROOTFS_CONFIG) not found!" && exit
. $MAKEROOTFS_CONFIG

! which $TARGET_CC && echo "ERROR: Can't find $TARGET_CC in PATH!" && exit

FILE=mpeg2dec-0.4.0b.tar.gz
BASEURL=http://libmpeg2.sourceforge.net/files/
SRCDIR=mpeg2dec-0.4.0

echo === Building $FILE ===

cd $DOWNLOADS
[ ! -e "$FILE" ] && `$WGET $BASEURL$FILE`
cd $BUILDDIR
[ ! -e "$SRCDIR" ] && tar xvzf $DOWNLOADS/$FILE

cd $SRCDIR

./configure CC=$TARGET_CC CFLAGS="$TARGET_CFLAGS" --host=$CROSS_HOST --prefix=$ROOTFS_STAGING/usr \
	--without-x
	# --enable-shared

# cd libavcodec

make

# grep -l "install -s" `find .` | xargs -r -l1 sed -i -e "s/install -s/install/"
# grep -l "install -c -s" `find .` | xargs -r -l1 sed -i -e "s/install -c -s/install -c/"
make install
cd ..
