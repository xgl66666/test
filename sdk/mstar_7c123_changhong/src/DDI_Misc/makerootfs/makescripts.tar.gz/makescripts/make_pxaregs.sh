#!/bin/sh
#
# Author: Matthias Ihmig <m.ihmig@mytum.de>
# Last change: 6/25/2005
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU Library General Public License

set -e

[ -z "$MAKEROOTFS_CONFIG" ] && MAKEROOTFS_CONFIG=$PWD/makerootfs.conf
[ ! -e $MAKEROOTFS_CONFIG ] && echo "ERROR: Config file ($MAKEROOTFS_CONFIG) not found!" && exit
. $MAKEROOTFS_CONFIG

! which $TARGET_CC && echo "ERROR: Can't find $TARGET_CC in PATH!" && exit

FILE=pxaregs.c
BASEURL=http://www.mn-logistik.de/unsupported/pxa250/
SRCDIR=pxaregs

echo === Building $FILE ===

cd $DOWNLOADS
[ ! -e "$FILE" ] && `$WGET $BASEURL$FILE`
cd $BUILDDIR
[ ! -e "$SRCDIR" ] && mkdir $SRCDIR && cp $DOWNLOADS/$FILE $SRCDIR

cd $SRCDIR

[ ! -e $BUILDDIR/$SRCDIR/.patch_applied ] && patch -N -p0 < $PATCHES/pxa27xregs.patch
touch $BUILDDIR/$SRCDIR/.patch_applied

$TARGET_CC $SRCDIR.c -o $SRCDIR

mkdir -p $ROOTFS_STAGING/usr/bin/
install -m 0755 pxaregs $ROOTFS_STAGING/usr/bin/pxa27xregs

cd ..

