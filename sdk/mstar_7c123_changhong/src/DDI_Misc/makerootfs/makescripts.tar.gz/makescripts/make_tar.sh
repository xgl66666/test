#!/bin/sh
#
# Author: Matthias Ihmig <m.ihmig@mytum.de>
# Last change: 6/25/2005
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU Library General Public License

set -e
echo === Building test ===
echo "include var_list"
VAR_LIST=../../../bsp/linux/partition/auto_gen_output/var_list
[ ! -e ${VAR_LIST} ] && echo "ERROR: Config file ${VAR_LIST} not found!" && exit 1
source ${VAR_LIST}
MAKEROOTFS_CONFIG=../../../../../../DDI_Misc/makerootfs/makerootfs.conf
#[ -z "$MAKEROOTFS_CONFIG" ] && MAKEROOTFS_CONFIG=$PWD/makerootfs.conf
[ ! -e $MAKEROOTFS_CONFIG ] && echo "ERROR: Config file ($MAKEROOTFS_CONFIG) not found!" && exit
. $MAKEROOTFS_CONFIG

! which $TARGET_CC && echo "ERROR: Can't find $TARGET_CC in PATH!" && exit

FILE=tar-1.14.91.tar.gz
BASEURL=ftp://alpha.gnu.org/gnu/tar/
SRCDIR=tar-1.14.91

echo === Building $FILE ===

cd $DOWNLOADS
[ ! -e "$FILE" ] && `$WGET $BASEURL$FILE`
cd $BUILDDIR
[ ! -e "$SRCDIR" ] && tar xvzf $DOWNLOADS/$FILE

cd $SRCDIR

CC=$TARGET_CC CFLAGS="$TARGET_CFLAGS" ./configure --host=$CROSS_HOST --build=i386-linux --prefix=/usr --disable-nls

make
make DESTDIR=$ROOTFS_STAGING install
mkdir -p $ROOTFS_STAGING/bin
mv $ROOTFS_STAGING/usr/bin/tar $ROOTFS_STAGING/bin/
rm $ROOTFS_STAGING/usr/libexec/rmt && rmdir $ROOTFS_STAGING/usr/libexec

cd ..

