#!/bin/sh
while true;
	do
	rfcomm show rfcomm0 > /dev/null 2> /dev/null
	if [ "$?" != "1" ] ; then
		/sbin/getty -w -L rfcomm0 115200 vt100;
	fi
	sleep 3;
done
