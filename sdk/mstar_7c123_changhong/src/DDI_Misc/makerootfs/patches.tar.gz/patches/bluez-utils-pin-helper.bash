#!/bin/bash
# use pre-defined pin or ask user for pin (configure in default/bluetooth)
#
# Author: Matthias Ihmig <m.ihmig@mytum.de>, 2005

BT_USEDEFAULTPIN=false

[ -e /etc/default/bluetooth ] && . /etc/default/bluetooth
if [ $BT_USEDEFAULTPIN == false ]
then
read -p "Enter Bluetooth PIN: "
echo "PIN:$REPLY"
else
echo -n "PIN:"
cat /etc/bluetooth/pin
fi
