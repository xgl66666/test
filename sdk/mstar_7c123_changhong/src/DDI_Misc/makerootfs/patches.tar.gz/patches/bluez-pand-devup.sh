#!/bin/sh
/sbin/ifup $1
